﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace Coursework1
{
    public partial class Registration : Form
    {
        
        public Registration()
        {
            InitializeComponent();
            checkBox1.Visible = Program.isadmin;
            if (Program.isadmin == false)
            {
                textBox3.Text = Program.user_name;
                textBox4.Text = Program.pass_word;
            }

        }

        private void checkBox1_MouseHover(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            checkBox1.Text = "Login is admin";
            else
            checkBox1.Text = "Login is user";
        }

        private void checkBox1_MouseLeave(object sender, EventArgs e)
        {
            checkBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text.Trim() == "" || textBox1.Text.Trim() == "")
                {
                    MessageBox.Show("At least one of password fields is empty");
                }
                else
                {
                    if (textBox4.Text.Trim() != textBox1.Text.Trim())
                        MessageBox.Show("Passwords don't match");
                    else
                    {
                        try
                        {
                            string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                                Program.catalog + ";User ID =compadmin;Password=123";
                            SqlConnection sqlcon = new SqlConnection(connection);
                            SqlCommand cmd = new SqlCommand("dbo.CreateUser", sqlcon);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@username", SqlDbType.NVarChar, 128);
                            cmd.Parameters.Add("@pwd", SqlDbType.NVarChar, 128);
                            cmd.Parameters.Add("@isadmin", SqlDbType.Bit);
                            cmd.Parameters["@username"].Value = textBox3.Text.Trim();
                            cmd.Parameters["@pwd"].Value = textBox4.Text.Trim();
                            if (Program.isadmin == false)
                                cmd.Parameters["@isadmin"].Value = false;
                            else
                            {
                                if (checkBox1.Checked)
                                    cmd.Parameters["@isadmin"].Value = true;
                                else
                                    cmd.Parameters["@isadmin"].Value = false;
                            }
                            var returnParameter = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                            returnParameter.Direction = ParameterDirection.ReturnValue;
                            sqlcon.Open();
                            cmd.ExecuteNonQuery();
                            var result = returnParameter.Value;
                            Program.user_name = textBox3.Text.Trim();
                            Program.pass_word = textBox4.Text.Trim();
                            if (result.ToString() == "0")
                            {
                                //Hide();
                                //var form1 = new Form1();
                                //form1.Closed += (s, args) => Close();
                                //Form1 o = new Form1();
                                //o.Show();
                                Form1 acs = new Form1();
                                acs.ShowDialog();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show(result.ToString());
                            }
                            sqlcon.Close();
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("C# Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

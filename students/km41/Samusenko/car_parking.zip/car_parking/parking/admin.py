from django.contrib import admin

from .models import Car, ParkingPlace


admin.site.register(Car)
admin.site.register(ParkingPlace)

<?php
if(!isset($_COOKIE['login'])){
    header("Location: main.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	
	
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	<style>#name{width: 300px; margin-left: 400;}</style>
	
	

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="personalpage.php">Personal Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<section>
		<a href="personalpage.php"><button class="btn btn-green btn-fill-vert">MY TOURNAMENTS</button></a>
		<a href="newtournament.php"><button class="btn btn-green btn-fill-vert">NEW TOURNAMENT</button></a>
		<a href="#"><button class="btn btn-green btn-fill-vert">SEND MESSAGE</button></a>
	</section>
	
    <!-- Page Content -->
    <div class="container">
	<h1 class="mt-5">NEW MESSAGE</h1>
		<div class="form">
			<form  action="messagephp.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="user">Email</label>
					<input type="text" name="organizer_email" class="form-control" align="center" placeholder="Email" id="name" required/>
				</div>		
				<div class="form-group">
					<hr>
					<p><textarea rows="10" cols="45" pattern=".{2,40}$" title="This value is not valid" name="messg" id="messg"></textarea></p>
				</div>	
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >send message<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
		</div>
	
	</div>
    <!-- /.container -->	

  </body>

</html>
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.urls import reverse
from django.db import connection
from django.db import transaction

from .models import Phone
from orders.models import Order


@method_decorator(login_required, name='dispatch')
class ViewPhone(View):

    def get(self, request, pk):
        phone = Phone.objects.get(pk=pk)
        user = request.user

        users_orders = Order.objects.filter(phone_id=phone.id)

        context = {'phone': phone,
                   'user': user,
                   'users_orders': users_orders} 

        return render(request, 'phones/phone-details.html', context)

    def post(self, request, pk):
        quantity = request.POST.get('quantity')
        phone = Phone.objects.get(pk=pk)

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
            order = Order.objects.create(user=request.user, phone=phone, quantity=quantity)


        # phone.quantity -= 1  # Replaced by TRIGGER phone_quantity_extract
        # phone.save()
        return redirect(reverse('orders:view_order', args=(order.id, )))

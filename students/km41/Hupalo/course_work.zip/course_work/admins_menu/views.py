from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.urls import reverse
from django.utils import timezone
from django.db import connection
from django.db import transaction

from cleaning.models import Cleaning_company, Cleaner, Order
from .forms import Cleaning_companyForm

@method_decorator(login_required, name='dispatch')
class AdminMenu(View):

    def get(self, request):
        companies = Cleaning_company.objects.all()
        form = Cleaning_companyForm()
        return render(request, 'admin/admin.html', {'companies': companies, 'form': form})

    def post(self, request):
        companies = Cleaning_company.objects.all()

        form = Cleaning_companyForm(request.POST, request.FILES)
        if form.is_valid():
            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price_per_square_metr = int(request.POST.get('price_per_square_metr'))
            city = request.POST.get('city')
            square_meters_per_hour = int(request.POST.get('square_meters_per_hour'))

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('COMPANY_PACKAGE.ADD_NEW', [
                    name,
                    description,
                    price_per_square_metr,
                    city,
                    square_meters_per_hour])

            return redirect(reverse('admins_menu:admin_menu'))

        return render(request, 'admin/admin.html', {'companies': companies, 'form': form})



@method_decorator(login_required, name='dispatch')
class EditMenu(View):

    def get(self, request, pk):
        company = Cleaning_company.objects.get(pk=pk)
        form = Cleaning_companyForm(instance=company)

        return render(request, 'admin/edit.html', {'company': company, 'form': form})

    def post(self, request, pk):
        company = Cleaning_company.objects.get(pk=pk)
        form = Cleaning_companyForm(request.POST, request.FILES, instance=company)

        if form.is_valid():
            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price_per_square_metr = int(request.POST.get('price_per_square_metr'))
            city = request.POST.get('city')
            square_meters_per_hour = int(request.POST.get('square_meters_per_hour'))

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('COMPANY_PACKAGE.EDIT', [
                    pk,
                    name,
                    description,
                    price_per_square_metr,
                    city,
                    square_meters_per_hour])
            
            return redirect(reverse('admins_menu:admin_menu'))

        return render(request, 'admin/edit.html', {'company': company, 'form': form})

@method_decorator(login_required, name='dispatch')
class DeleteMenu(View):

    def post(self, request, pk):

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('COMPANY_PACKAGE.DEL', [pk])

        return redirect(reverse('admins_menu:admin_menu'))



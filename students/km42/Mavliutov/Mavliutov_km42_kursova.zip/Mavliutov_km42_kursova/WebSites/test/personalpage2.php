<?php
if(!isset($_COOKIE['login'])){
    header("Location: main.php"); exit;
}
?>

<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

    <!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Personal Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<section>
		<h1 class="mt-5"><?php echo 'Hello, '.$_COOKIE['login'] ?></h1>
		<a href="#"><button class="btn btn-green btn-fill-vert">MY TOURNAMENTS</button></a>
		<a href="newtournament.php"><button class="btn btn-green btn-fill-vert">NEW TOURNAMENT</button></a>
		<a href="message.php"><button class="btn btn-green btn-fill-vert">NEW MESSAGE</button></a>
	</section>
	
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5">MY TOURNAMENTS</h1>
	  <div class="form">
			<form  action="filterlisttournament.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="filter"><b>Search Tournament</b></label>
					<input type="text" name="filter_tournament_name" pattern=".{1,10}$" title="This value is not valid" class="form-control" placeholder="Tournament name" required/>
				</div>			
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >SEARCH<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
		</div>

    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		$connect = oci_connect('YAROSLAV', 'mavliutov1997', 'localhost/XE');
		if (!$connect) {
			$e = oci_error();
			trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
		}
		$countmytourn = oci_parse($connect, 'SELECT getcounttourn(:organizer) FROM dual');
		oci_bind_by_name($countmytourn, ":organizer", $_COOKIE['login']);
		oci_execute($countmytourn);
		$row = oci_fetch_array($countmytourn, OCI_ASSOC);
		if (!$row) {$mycount = 0;}
		else {foreach ($row as $mycount){}}
		echo '<h3 class="mt-5">'.$mycount.' RESULTS</h3>';
		
		$stid = oci_parse($connect, 'SELECT tourn_id, org_login_fk,
									 tourn_name,tourn_data_started, tourn_data_end
									 FROM Tournament_for_admin
									 where org_login_fk = :organizer_name');
		oci_bind_by_name($stid, ":organizer_name", $_COOKIE['login']);
		oci_execute($stid);

		$i = 0;
		$tourns = array();
		while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
			$j = 0;
			foreach ($row as $item) {
				if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
				$j++;
			}
			$i++;
		}
		for ($i = 0; $i < count($tourns); $i++) {
			$name = $tourns[$i][1];
			$id = $tourns[$i][0];
			$nametourn = $tourns[$i][2];
			echo '<hr><font color="317E0E"><b>Name Tournament: </b></font>'.$tourns[$i][2].'<br>'.' <font color="317E0E"><b>Start Date: </b></font>'.$tourns[$i][3].'<br>'.' <font color="317E0E"><b>End Date: </b></font>'.$tourns[$i][4].'<br>'.'
				 <form method="POST" action="abouttournament.php">
				 <input name="id_tourn" type="hidden" class="form-control" value="'.$id.'" required/>
				 <input name="org_login" type="hidden" class="form-control" value="'.$name.'" required/>	 
				 <input name="tourn_n" type="hidden" class="form-control" value="'.$nametourn.'" required/>	
				 <button class="btn btn-blue btn-fill-vert">more details</button>
				 </form> ';
		}
		
		oci_free_statement($countmytourn);
		oci_free_statement($stid);
		oci_close($connect);
		
	?>
	</div>
    <!-- /.container -->
	
	
  </body>

</html>
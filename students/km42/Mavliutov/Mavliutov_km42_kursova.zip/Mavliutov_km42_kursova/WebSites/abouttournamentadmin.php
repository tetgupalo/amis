<?php
if(!isset($_COOKIE['admin'])){
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

    <!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="adminpage.php">Admin Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5"><?php echo $_POST['org_login'];?></h1>

    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		if (strcasecmp($_POST['action'], 'tournaments') == 0 ) {

			$countmytourn = oci_parse($connect, 'SELECT countnumber.getcounttourn(:organizer) FROM dual');
			oci_bind_by_name($countmytourn, ":organizer", $_POST['login_org']);
			oci_execute($countmytourn);
			$row = oci_fetch_array($countmytourn, OCI_ASSOC);
			if (!$row) {$mycount = 0;}
			else {foreach ($row as $mycount){}}
			echo '<h3 class="mt-5">'.$mycount.' RESULTS</h3>';
				
			$stid = oci_parse($connect, 'BEGIN selectdata.SelecttournamentData(:organizer_name, :MYTABLE); END;');
			oci_bind_by_name($stid, ":organizer_name", $_POST['login_org']);
			$mytable = oci_new_cursor($connect);
			oci_bind_by_name($stid,":MYTABLE",$mytable,-1,OCI_B_CURSOR);
			oci_execute($stid);
			oci_execute($mytable);
			$i = 0;
			$tourns = array();
			while ($entry = oci_fetch_array($mytable, OCI_ASSOC+OCI_RETURN_NULLS)) {
				$j = 0;
				foreach ($entry as $item) {
					if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
					$j++;
				}
				$i++;
			}
			
			for ($i = 0; $i < count($tourns); $i++) {
				$name = $tourns[$i][1];
				$id = $tourns[$i][0];
				$nametourn = $tourns[$i][2];
				$startd= $tourns[$i][3];
				$endt = $tourns[$i][4];
				echo '<hr><font color="317E0E"><b>Name Tournament: </b></font>'.$tourns[$i][2].'<br>'.' <font color="317E0E"><b>Start Date: </b></font>'.$tourns[$i][3].'<br>'.' <font color="317E0E"><b>End Date: </b></font>'.$tourns[$i][4].'<br>'.'
					 <form method="POST" action="aboutmatchadmin.php">
					 <input name="id_tourn" type="hidden" class="form-control" value="'.$id.'" required/>
					 <input name="org_login" type="hidden" class="form-control" value="'.$name.'" required/>	 
					 <input name="tourn_n" type="hidden" class="form-control" value="'.$nametourn.'" required/>	
					 <input name="start_t" type="hidden" class="form-control" value="'.$startd.'" required/>	
					 <input name="end_t" type="hidden" class="form-control" value="'.$endt.'" required/>	
					 <!--<button class="btn btn-purple btn-fill-vert">more details</button>-->
					 <input class="btn btn-purple btn-fill-vert" type="submit" name="action" value="games" />
					 <input class="btn btn-red btn-fill-vert" type="submit" name="action" value="delete" />
					 </form> ';
			}
			
			oci_free_statement($countmytourn);
			oci_free_statement($stid);
			oci_close($connect);
			
		} else if (strcasecmp($_POST['action'], 'delete') == 0 ) {
		

		
			
			
			$delete4 = 'BEGIN changespro.deleteorganizer(:login); END;';
			$compiled4 = oci_parse($connect, $delete4);
			oci_bind_by_name($compiled4, ':login', $_POST['login_org']);
			oci_execute($compiled4);
			oci_commit($connect);


			oci_free_statement($complited4);
			oci_close($connect);
			header("Location: adminpage.php"); exit;
			
			oci_close($connect);	
		}
		//oci_close($connect);
	?>
	
		
	</div>
    <!-- /.container -->
	
	
  </body>

</html>
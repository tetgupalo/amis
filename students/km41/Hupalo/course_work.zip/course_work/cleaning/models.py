from django.db import models


class Cleaning_company(models.Model):
    name = models.CharField(
        'Company name',
        max_length=30,
        default='No name',
    )
    description = models.CharField(
        'Description',
        max_length=255,
        blank=True,
        null=True,
    )
    price_per_square_metr = models.PositiveIntegerField(
        'Price per square metr',
        null=True,
        blank=True,
        default=0,
    )
    city = models.CharField(
        'City',
        max_length=30,
        blank=True,
        null=True,
    )
    square_meters_per_hour = models.PositiveIntegerField(
        'Square metr per hour',
        null=True,
        blank=True,
        default=1,
    )
    company_logo = models.ImageField(
        'Company logo',
        upload_to='logo_images/',
        blank=True,
        default='logo_images/no_logo.jpg',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Cleaning company"
        verbose_name_plural = "Cleaning companies"


class Cleaner(models.Model):
    name = models.CharField(
        'Cleaner name',
        max_length=30,
        default='No name',
    )
    cleaning_company = models.ForeignKey(
        'Cleaning_company',
        verbose_name='cleaning_company',
        on_delete=models.SET_NULL,
        null=True,
    )
    money_earned = models.PositiveIntegerField(
        'Money earned',
        null=True,
        blank=True,
        default=0,
    )
    busy_from = models.DateTimeField(
        'Busy from',
        blank=True,
        null=True,
    )
    busy_to = models.DateTimeField(
        'Busy to',
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Cleaner"
        verbose_name_plural = "Cleaner"


class Order(models.Model):
    user = models.ForeignKey(
        'auth.User',
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    cleaning_person = models.ForeignKey(
        'Cleaner',
        verbose_name='Cleaning_person',
    )
    square_meters = models.PositiveIntegerField(
        'Square meters',
        null=True,
        blank=True,
        default=0,
    )
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )

    def __str__(self):
        return '{username}\'s order of cleaner {cleaner} from company {company} on {order_time}'.format(
        	username=self.user.username,
            cleaner=self.cleaning_person.name,
            company=self.cleaning_person.cleaning_company.name,
            order_time=self.create_time)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"


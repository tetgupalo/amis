<?php
if(!isset($_COOKIE['admin'])){
    header("Location: personalpage.php"); exit;
}
?>

<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

    <!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Admin Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<section>
		<h1 class="mt-5"><?php echo 'Hello, '.$_COOKIE['login'] ?></h1>
	</section>
	
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5">ALL USERS</h1>
	  <!--<div class="form">
			<form  action="filterlisttournament.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="filter"><b>Search Tournament</b></label>
					<input type="text" name="filter_tournament_name" pattern=".{1,10}$" title="This value is not valid" class="form-control" placeholder="Tournament name" required/>
				</div>			
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >SEARCH<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
		</div>-->

    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		$countmytourn = oci_parse($connect, 'SELECT COUNT(*)
											 FROM Organizer_for_admin 
											 WHERE org_del = :del and org_admin = :admin');
		$adm = 0;
		$del = 0;
		oci_bind_by_name($countmytourn, ":admin", $adm);
		oci_bind_by_name($countmytourn, ":del", $del);
		oci_execute($countmytourn);
		$row = oci_fetch_array($countmytourn, OCI_ASSOC);
		if (!$row) {$mycount = 0;}
		else {foreach ($row as $mycount){}}
		echo '<h3 class="mt-5">'.$mycount.' RESULTS</h3>';
			
		$stid = oci_parse($connect, 'BEGIN selectdata.SelectorganizerData(:MYTABLE); END;');
		$mytable = oci_new_cursor($connect);
		oci_bind_by_name($stid,":MYTABLE",$mytable,-1,OCI_B_CURSOR);
		oci_execute($stid);
		oci_execute($mytable);
		$i = 0;
		$tourns = array();
		while ($entry = oci_fetch_array($mytable, OCI_ASSOC+OCI_RETURN_NULLS)) {
			$j = 0;
			foreach ($entry as $item) {
				if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
				$j++;
			}
			$i++;
		}
		
		for ($i = 0; $i < count($tourns); $i++) {
			$login = $tourns[$i][0];
			$email = $tourns[$i][1];
			echo '<hr><font color="317E0E"><b>User Login: </b></font>'.$login.'<br>'.' <font color="317E0E"><b>User Email: </b></font>'.$email.'<br>'.'
				 <form method="POST" action="abouttournamentadmin.php">
				 <input name="org_email" type="hidden" class="form-control" value="'.$email.'" required/>
				 <input name="login_org" type="hidden" class="form-control" value="'.$login.'" required/>	 
				 <!--<button class="btn btn-purple btn-fill-vert">more details</button>-->
				 <input class="btn btn-purple btn-fill-vert" type="submit" name="action" value="tournaments" />
				 <input class="btn btn-red btn-fill-vert" type="submit" name="action" value="delete" />
				 </form> ';
		}
		
		oci_free_statement($countmytourn);
		oci_free_statement($stid);
		oci_close($connect);
		
	?>
	</div>

	
  </body>

</html>
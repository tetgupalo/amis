<?php
if(isset($_COOKIE['login'])){
	if(isset($_COOKIE['admin'])){
		header("Location: adminpage.php"); exit;
	}
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

	<!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>

  </head>

  <body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#e">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#ex2">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Sign up</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Sign in</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Page Content -->
    <div class="container">
      <h2 class="mt-5">Are you ready to manage the football tournaments?</h2>
      <p>Join millions of users who already trust Challonge to manage their tournaments. More than 3 tournaments have already been created.</p>

	<div class="form">
			<form  action="mainfilter.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="filter"><b>Search Tournament</b></label>
					<input type="text" name="filter1_tournament_name" pattern="^([A-z0-9,A-z0-9]{1,30})$" title="This value is not valid" class="form-control" placeholder="Tournament name" required/>
				</div>			
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >SEARCH<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
	</div>

    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		
		$stid = oci_parse($connect, 'BEGIN selectdata.Selecttourninfo(:org_name,:tourn_id, :MYTABLE); END;');
		oci_bind_by_name($stid, ":tourn_id", $_POST['id_tourn']);
		oci_bind_by_name($stid, ":org_name", $_POST['org_login']);
		$mytable = oci_new_cursor($connect);
		oci_bind_by_name($stid,":MYTABLE",$mytable,-1,OCI_B_CURSOR);
		oci_execute($stid);
		oci_execute($mytable);
		$i = 0;
		$tourns = array();
		while ($entry = oci_fetch_array($mytable, OCI_ASSOC+OCI_RETURN_NULLS)) {
			$j = 0;
			foreach ($entry as $item) {
				if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
				$j++;
			}
			$i++;
		}
		for ($i = 0; $i < count($tourns); $i++) {

			$sel1 = oci_parse($connect, 'BEGIN selectdata.getteamname(:email1, :t_name1); END;');
			oci_bind_by_name($sel1, ":email1", $tourns[$i][1]);
			oci_bind_by_name($sel1,':t_name1',$item1,32);
			$sel2 = oci_parse($connect, 'BEGIN selectdata.getteamname(:email2, :t_name2); END;');
			oci_bind_by_name($sel2, ":email2", $tourns[$i][2]);
			oci_bind_by_name($sel2,':t_name2',$item2,32);
			oci_execute($sel1);
			oci_execute($sel2);
			
			$nume = 0;
				$goal1 = oci_parse($connect, 'Select countnumber.getcountgoals(:goal_email, :datematch, :other_email, :nume) from dual');
				oci_bind_by_name($goal1, ":goal_email", $tourns[$i][1]);
				oci_bind_by_name($goal1, ":other_email", $tourns[$i][2]);
				oci_bind_by_name($goal1, ":nume", $nume);
				oci_bind_by_name($goal1, ":datematch", $tourns[$i][0]);
				//echo $tourns[$i][1].' '.$tourns[$i][2].' '.$tourns[$i][0].' '.$nume;
				oci_execute($goal1);
				$countgoal1 = oci_fetch_array($goal1, OCI_ASSOC);
				if (!$countgoal1) {$countteam1 = 0;}
				else {foreach ($countgoal1 as $countteam1){}}
				
				$nume = 1;
				$goal2 = oci_parse($connect, 'Select countnumber.getcountgoals(:goal_email, :datematch, :other_email, :nume) from dual');
				oci_bind_by_name($goal2, ":nume", $nume);
				oci_bind_by_name($goal2, ":goal_email", $tourns[$i][2]);
				oci_bind_by_name($goal2, ":other_email", $tourns[$i][1]);
				oci_bind_by_name($goal2, ":datematch", $tourns[$i][0]);
				oci_execute($goal2);
				$countgoal2 = oci_fetch_array($goal2, OCI_ASSOC);
				if (!$countgoal2) {$countteam2 = 0;}
				else {foreach ($countgoal2 as $countteam2){}}
				
			echo '<hr><font color="317E0E"><b>Date Match: </b></font>'.$tourns[$i][0].'<br><b>'.$item1.'</b> '.' <font color="BC0407"><b>VS </b></font><b>'.$item2.'</b><br>'.'
				  <font color="317E0E"><b>RESULT: </b></font><b>'.$countteam1.'</b> '.' : <b>'.$countteam2.'</b>';		
			
		}
		oci_free_statement($sel1);
		oci_free_statement($sel2);		
		oci_free_statement($goal1);
		oci_free_statement($goal2);
		oci_free_statement($stid);
		oci_close($connect);
	?>
	
	
<section id="ex2">

</section>
	
	
	
	</div>

  </body>

</html>
from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth import login, logout, authenticate
from .forms import SignUpForm, EditProfileInfo, EditProfilePhoto
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.template.loader import render_to_string
from .tokens import account_activation_token
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse
from django.contrib.auth import update_session_auth_hash

# from django.contrib.auth.models import User
from django.utils.encoding import force_text
from django.utils.http import urlsafe_base64_decode

from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.utils.decorators import method_decorator

from django.db import transaction, DatabaseError

from phones.models import Phone
from orders.models import Order
from home.models import Profile
# from .tasks import send_email

class SignUp(View):
    singup_form = SignUpForm
    template_name = 'registration/signup.html'

    def get(self, request):
        form = self.singup_form()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.singup_form(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save()
                    user.refresh_from_db()
                    user.is_active = False

                    user.save()
            except Exception:
                return redirect('/database_error/')

            current_site = get_current_site(request)
            subject = 'Activate Your Buy Phone Account'
            message = render_to_string('registration/account_activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            user.email_user(subject, message)

            # Celery task
            # send_email.delay(user=user, current_site=current_site.domain)

            return redirect('/')
        return render(request, self.template_name, {'form': form})


def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = Profile.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, Profile.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        return redirect('/')
    else:
        return render(request, 'registration/account_activation_invalid.html')

def account_activation_sent(request):
    return render(request, 'home.html')


@method_decorator(login_required, name='dispatch')
class ViewProfile(View):
    template_name = 'accounts/profile.html'

    def get(self, request, pk=None):

        if pk:
            user = Profile.objects.get(pk=pk)
        else:
            user = request.user

        if request.user.id == user.id:
            is_own = True
        else:
            is_own = False

        user_orders = Order.objects.filter(user_id=user.id)


        context = {'user': user, 'is_own': is_own, 'user_orders': user_orders}
        return render(request, self.template_name, context)

@login_required(login_url='/login/')
def edit_profile(request):

    if request.method == 'POST':        
        profile_form = EditProfilePhoto(request.POST, request.FILES, instance=request.user)
        user_form = EditProfileInfo(request.POST, instance=request.user)

        if profile_form.is_valid():
            profile_form.save()
            return redirect(reverse('home:edit_profile'))

        if user_form.is_valid():
            user_form.save()
            return redirect(reverse('home:edit_profile'))


    else:
        profile_form = EditProfilePhoto(instance=request.user)
        user_form = EditProfileInfo(instance=request.user)


    context = {'profile_form': profile_form, 'user_form': user_form}
    return render(request, 'accounts/edit_profile.html', context)


@method_decorator(login_required, name='dispatch')
class ChangePassword(View):
    form = PasswordChangeForm
    template_name = 'accounts/change_password.html'

    def get(self, request):
        form = self.form(user=request.user)
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form(data=request.POST, user=request.user)

        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect(reverse('home:view_profile'))
        return render(request, self.template_name, {'form': form})

def recommendation_list():

    return Phone.objects.raw('SELECT * FROM PHONES_PHONE WHERE ROWNUM <= 4')
    # return Phone.objects.all()[:4]

def all_phones_list():

    return Phone.objects.all()

<?php
if(!isset($_COOKIE['admin'])){
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

    <!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	<style>#name{width: 300px; margin-left: 400;}</style>
	<style>#date{width: 200px; margin-left: 400;}</style>
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="adminpage.php">Admin Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
		
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5"><?php echo $_POST['org_login'].'/'.$_POST['tourn_n'];?></h1>

    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		if (strcasecmp($_POST['action'], 'games') == 0 ) {

			$stid = oci_parse($connect, 'BEGIN selectdata.Selecttourninfo(:org_name,:tourn_id, :MYTABLE); END;');
			oci_bind_by_name($stid, ":tourn_id", $_POST['id_tourn']);
			oci_bind_by_name($stid, ":org_name", $_POST['org_login']);
			$mytable = oci_new_cursor($connect);
			oci_bind_by_name($stid,":MYTABLE",$mytable,-1,OCI_B_CURSOR);
			oci_execute($stid);
			oci_execute($mytable);
			$i = 0;
			$tourns = array();
			while ($entry = oci_fetch_array($mytable, OCI_ASSOC+OCI_RETURN_NULLS)) {
				$j = 0;
				foreach ($entry as $item) {
					if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
					$j++;
				}
				$i++;
			}
			
			for ($i = 0; $i < count($tourns); $i++) {

			
				$sel1 = oci_parse($connect, 'BEGIN selectdata.getteamname(:email1, :t_name1); END;');
				oci_bind_by_name($sel1, ":email1", $tourns[$i][1]);
				oci_bind_by_name($sel1,':t_name1',$item1,32);
				$sel2 = oci_parse($connect, 'BEGIN selectdata.getteamname(:email2, :t_name2); END;');
				oci_bind_by_name($sel2, ":email2", $tourns[$i][2]);
				oci_bind_by_name($sel2,':t_name2',$item2,32);
				oci_execute($sel1);
				oci_execute($sel2);
				
				$nume = 0;
				$goal1 = oci_parse($connect, 'Select countnumber.getcountgoals(:goal_email, :datematch, :other_email, :nume) from dual');
				oci_bind_by_name($goal1, ":goal_email", $tourns[$i][1]);
				oci_bind_by_name($goal1, ":other_email", $tourns[$i][2]);
				oci_bind_by_name($goal1, ":nume", $nume);
				oci_bind_by_name($goal1, ":datematch", $tourns[$i][0]);
				//echo $tourns[$i][1].' '.$tourns[$i][2].' '.$tourns[$i][0].' '.$nume;
				oci_execute($goal1);
				$countgoal1 = oci_fetch_array($goal1, OCI_ASSOC);
				if (!$countgoal1) {$countteam1 = 0;}
				else {foreach ($countgoal1 as $countteam1){}}
				
				$nume = 1;
				$goal2 = oci_parse($connect, 'Select countnumber.getcountgoals(:goal_email, :datematch, :other_email, :nume) from dual');
				oci_bind_by_name($goal2, ":nume", $nume);
				oci_bind_by_name($goal2, ":goal_email", $tourns[$i][2]);
				oci_bind_by_name($goal2, ":other_email", $tourns[$i][1]);
				oci_bind_by_name($goal2, ":datematch", $tourns[$i][0]);
				oci_execute($goal2);
				$countgoal2 = oci_fetch_array($goal2, OCI_ASSOC);
				if (!$countgoal2) {$countteam2 = 0;}
				else {foreach ($countgoal2 as $countteam2){}}
				
				echo '<hr><font color="317E0E"><b>Date Match: </b></font>'.$tourns[$i][0].'<br><b>'.$item1.'</b> '.' <font color="BC0407"><b>VS </b></font><b>'.$item2.'</b><br>'.'
					  <font color="317E0E"><b>RESULT: </b></font><b>'.$countteam1.'</b> '.' : <b>'.$countteam2.'</b>'.'
					 <form method="post" action="aboutgoals.php">
					 <input class="btn btn-purple btn-fill-vert" type="submit" name="action" value="goals" />
					 <input class="btn btn-red btn-fill-vert" type="submit" name="action" value="delete" />
					 <input name="emailteam1" type="hidden" class="form-control" value="'.$tourns[$i][1].'" required/>
					 <input name="emailteam2" type="hidden" class="form-control" value="'.$tourns[$i][2].'" required/>
					 <input name="nameteam1" type="hidden" class="form-control" value="'.$item1.'" required/>
					 <input name="nameteam2" type="hidden" class="form-control" value="'.$item2.'" required/>	
					 <input name="goalteam1" type="hidden" class="form-control" value="'.$countteam1.'" required/>
					 <input name="goalteam2" type="hidden" class="form-control" value="'.$countteam2.'" required/>	
					 <input name="datamatch" type="hidden" class="form-control" value="'.$tourns[$i][0].'" required/>	
					 <input name="org_login" type="hidden" class="form-control" value="'.$_POST['org_login'].'" required/>	
					 <input name="tourn_n" type="hidden" class="form-control" value="'.$_POST['tourn_n'].'" required/>	
					 </form> '.'<br>';
			}
			oci_free_statement($sel1);
			oci_free_statement($sel2);		
			oci_free_statement($goal1);
			oci_free_statement($goal2);
			oci_free_statement($stid);
			oci_close($connect);
	
		} else if (strcasecmp($_POST['action'], 'delete') == 0 ) {
			
			
			$delete3 = 'BEGIN changespro.deletetourn(:login, :idtourn); END;';
			$compiled3 = oci_parse($connect, $delete3);
			oci_bind_by_name($compiled3, ':idtourn', $_POST['id_tourn']);
			oci_bind_by_name($compiled3, ':login', $_POST['org_login']);
			oci_execute($compiled3);
			oci_commit($connect);
			
			oci_free_statement($complited3);
			oci_close($connect);
			header("Location: adminpage.php"); exit;
		
		}
		//oci_close($connect);
	?>
	
		
	</div>
    <!-- /.container -->
	
	
  </body>

</html>
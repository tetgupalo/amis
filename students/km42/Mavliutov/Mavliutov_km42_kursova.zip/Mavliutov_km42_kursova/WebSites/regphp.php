<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php

session_start();//начать новий, або продовжити сеанс роботи	

  // Check validity of the supplied username & password
require('connect.php');

$login = oci_parse($connect, 'select *
                    from   Organizer_for_register
                    where  org_login = :new_login');
$email = oci_parse($connect, 'select *
                    from   Organizer_for_register
                    where  org_email = :new_email');	
oci_bind_by_name($login, ":new_login", $_POST['organizer_login']);
oci_bind_by_name($email, ":new_email", $_POST['organizer_email']);
oci_execute($login) or die("No execute!");
oci_execute($email) or die("No execute!");
$rlogin = oci_fetch_array($login, OCI_ASSOC);
$remail = oci_fetch_array($email, OCI_ASSOC);
if ($rlogin) {
	oci_close($connect);
	echo 'Є такий логін';
			echo '<form action="register.php">
			<button type="submit">Добре(</button>
		</form>';
    //header("Location: register.php"); exit;
}
elseif($remail) {
	oci_close($connect);
	echo 'спробуй ще раз';
			echo '<form action="register.php">
			<button type="submit">Добре(</button>
		</form>';
	//header("Location: register.php"); exit;
}
else {
	$value_login = $_POST['organizer_login'];
	$value_email = $_POST['organizer_email'];
	$value_pass = $_POST['organizer_password'];
	$value_admin = 0;
	$value_del = 0;

	$insert = 'INSERT INTO ORGANIZER_FOR_REGISTER(org_login, org_email, org_pass, org_admin, org_del) '.
				'VALUES(:login, :email, :pass, :admin, :del)';

	$compiled = oci_parse($connect, $insert);
	oci_bind_by_name($compiled, ':login', $value_login);
	oci_bind_by_name($compiled, ':email', $value_email);
	oci_bind_by_name($compiled, ':pass', $value_pass);
	oci_bind_by_name($compiled, ':del', $value_del);
	oci_bind_by_name($compiled, ':admin', $value_admin);
	oci_execute($compiled);
	oci_commit($connect);
	setcookie('login', $_POST['organizer_login'], time() + (86400 * 30), "/");
	oci_free_statement($login);
	oci_free_statement($email);
	oci_close($connect);
	header("Location: personalpage.php"); exit;
}
	




?>
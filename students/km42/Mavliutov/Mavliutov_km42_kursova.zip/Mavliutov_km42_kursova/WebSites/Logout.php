<?php session_start();
unset($_SESSION['organizer_login1']);  // where $_SESSION["nome"] is your own variable. if you do not have one use only this as follow **session_unset();**
header("Location: main.php");
setcookie('login', -1, time()-7000000, '/');
setcookie('admin', -1, time()-7000000, '/');
?>
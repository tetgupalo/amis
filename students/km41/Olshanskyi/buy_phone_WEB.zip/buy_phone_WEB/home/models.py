from django.db import models

from django.contrib.auth.models import AbstractUser


class Profile(AbstractUser):
    user_photo = models.ImageField(
        upload_to='profile_image/',
        blank=True,
        default='profile_image/no_profile.jpg',
        verbose_name='File'
    )

﻿namespace Coursework1
{
    partial class Altertable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbname = new System.Windows.Forms.TextBox();
            this.tbvideo = new System.Windows.Forms.TextBox();
            this.tbvmemory = new System.Windows.Forms.TextBox();
            this.tbram = new System.Windows.Forms.TextBox();
            this.tbhdd = new System.Windows.Forms.TextBox();
            this.tbmoni = new System.Windows.Forms.TextBox();
            this.cbodrive = new System.Windows.Forms.CheckBox();
            this.cbmoni = new System.Windows.Forms.CheckBox();
            this.Changebutton = new System.Windows.Forms.Button();
            this.addbutton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.closebutton = new System.Windows.Forms.Button();
            this.clearbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Video card";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "GBs of video memory";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "RAM, GBs";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "HDD volume, GBs";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Optical  drive";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Monitor";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Monitor diagonal, inches";
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(141, 7);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(100, 20);
            this.tbname.TabIndex = 8;
            // 
            // tbvideo
            // 
            this.tbvideo.Location = new System.Drawing.Point(141, 33);
            this.tbvideo.Name = "tbvideo";
            this.tbvideo.Size = new System.Drawing.Size(100, 20);
            this.tbvideo.TabIndex = 9;
            // 
            // tbvmemory
            // 
            this.tbvmemory.Location = new System.Drawing.Point(141, 59);
            this.tbvmemory.Name = "tbvmemory";
            this.tbvmemory.Size = new System.Drawing.Size(100, 20);
            this.tbvmemory.TabIndex = 10;
            // 
            // tbram
            // 
            this.tbram.Location = new System.Drawing.Point(141, 85);
            this.tbram.Name = "tbram";
            this.tbram.Size = new System.Drawing.Size(100, 20);
            this.tbram.TabIndex = 11;
            // 
            // tbhdd
            // 
            this.tbhdd.Location = new System.Drawing.Point(141, 111);
            this.tbhdd.Name = "tbhdd";
            this.tbhdd.Size = new System.Drawing.Size(100, 20);
            this.tbhdd.TabIndex = 12;
            // 
            // tbmoni
            // 
            this.tbmoni.Location = new System.Drawing.Point(141, 188);
            this.tbmoni.Name = "tbmoni";
            this.tbmoni.Size = new System.Drawing.Size(100, 20);
            this.tbmoni.TabIndex = 13;
            // 
            // cbodrive
            // 
            this.cbodrive.AutoSize = true;
            this.cbodrive.Location = new System.Drawing.Point(184, 138);
            this.cbodrive.Name = "cbodrive";
            this.cbodrive.Size = new System.Drawing.Size(15, 14);
            this.cbodrive.TabIndex = 14;
            this.cbodrive.UseVisualStyleBackColor = true;
            // 
            // cbmoni
            // 
            this.cbmoni.AutoSize = true;
            this.cbmoni.Location = new System.Drawing.Point(184, 165);
            this.cbmoni.Name = "cbmoni";
            this.cbmoni.Size = new System.Drawing.Size(15, 14);
            this.cbmoni.TabIndex = 15;
            this.cbmoni.UseVisualStyleBackColor = true;
            // 
            // Changebutton
            // 
            this.Changebutton.Location = new System.Drawing.Point(263, 5);
            this.Changebutton.Name = "Changebutton";
            this.Changebutton.Size = new System.Drawing.Size(75, 23);
            this.Changebutton.TabIndex = 16;
            this.Changebutton.Text = "Change";
            this.Changebutton.UseVisualStyleBackColor = true;
            this.Changebutton.Click += new System.EventHandler(this.Changebutton_Click);
            // 
            // addbutton
            // 
            this.addbutton.Location = new System.Drawing.Point(263, 36);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(75, 23);
            this.addbutton.TabIndex = 17;
            this.addbutton.Text = "Add";
            this.addbutton.UseVisualStyleBackColor = true;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(263, 65);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // closebutton
            // 
            this.closebutton.Location = new System.Drawing.Point(263, 94);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(75, 22);
            this.closebutton.TabIndex = 19;
            this.closebutton.Text = "Close ";
            this.closebutton.UseVisualStyleBackColor = true;
            this.closebutton.Click += new System.EventHandler(this.closebutton_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(263, 122);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 20;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // Altertable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 217);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.closebutton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.addbutton);
            this.Controls.Add(this.Changebutton);
            this.Controls.Add(this.cbmoni);
            this.Controls.Add(this.cbodrive);
            this.Controls.Add(this.tbmoni);
            this.Controls.Add(this.tbhdd);
            this.Controls.Add(this.tbram);
            this.Controls.Add(this.tbvmemory);
            this.Controls.Add(this.tbvideo);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Altertable";
            this.Text = "Altertable";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Altertable_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.TextBox tbvideo;
        private System.Windows.Forms.TextBox tbvmemory;
        private System.Windows.Forms.TextBox tbram;
        private System.Windows.Forms.TextBox tbhdd;
        private System.Windows.Forms.TextBox tbmoni;
        private System.Windows.Forms.CheckBox cbodrive;
        private System.Windows.Forms.CheckBox cbmoni;
        private System.Windows.Forms.Button Changebutton;
        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button closebutton;
        private System.Windows.Forms.Button clearbutton;
    }
}
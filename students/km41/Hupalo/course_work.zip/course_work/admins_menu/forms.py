from cleaning.models import Cleaning_company
from django import forms
from django.forms.widgets import NumberInput, TextInput, DateTimeInput
import datetime

class Cleaning_companyForm(forms.ModelForm):
    name = forms.CharField(max_length=35)
    description = forms.CharField(max_length=35, required=False)
    price_per_square_metr = forms.IntegerField(required=True,
        widget=NumberInput(
            attrs={'class':'validate','min':"1",'max': "100"}))
    city = forms.CharField(max_length=35)
    square_meters_per_hour = forms.IntegerField(required=True,
        widget=NumberInput(
            attrs={'class':'validate','min':"1",'max': "100"}))

    class Meta:
        model = Cleaning_company
        # fields = '__all__'
        exclude = ('company_logo',)


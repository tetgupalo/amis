<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php
date_default_timezone_set('Africa/Lagos');


$err = 0;
require('connect.php');

$sdate =  date_format(date_create($_POST['tournament_data_started']),"d-M-Y ");
$tournament = oci_parse($connect, 'select *
                    from   Tournament_for_create
                    where  tourn_name = :new_tourn_name
					and	   tourn_data_started =:new_tourn_data_started and tourn_del = :del');
oci_bind_by_name($tournament, ":new_tourn_name", $_POST['tournament_name']);
oci_bind_by_name($tournament, ":new_tourn_data_started", $sdate);
$del = 0;
oci_bind_by_name($tournament, ":del", $del);


oci_execute($tournament) or die("No execute!");
$rtournament = oci_fetch_array($tournament, OCI_ASSOC);
$datateams  = $_POST['listteams'];
$teams = explode("\n", $datateams);

$arr_length = count($teams);
for($i = 0; $i < $arr_length - 1; $i++) {
    if (count(explode(",", $teams[$i])) != 2 ){
		echo 'Поганий ввід';
		$err = 1;
	}
	$email = explode(",", $teams[$i])[1];
	if (!filter_var(substr($email, 0, -1), FILTER_VALIDATE_EMAIL)) {
		echo 'email(';
		$err = 1;
	}
	$lenghtname = strlen(explode(",", $teams[$i])[0]);
	if ($lenghtname < 8 or $lenghtname > 31) {
		echo 'Довжини назв команд погані';
		$err = 1;
	}
	$lenghtemail = strlen(substr(explode(",", $teams[$i])[1], 0, -1));
	if ($lenghtemail < 8 or $lenghtemail > 51) $err = 1;
}

if (($arr_length - 1) != $_POST['count_participants']) {
	$err = 1;
	echo 'Кількість учасників != ту яку ви заповнили';
}


// перевірка чи є вже такі команди
if ($err == 0 ){
	for($i = 0; $i < $arr_length - 1; $i++){
		$participants = oci_parse($connect, 'select *
					from   Team_for_create
					where  tm_name =:new_tm_name');
		oci_bind_by_name($participants, ":new_tm_name", explode(",", $teams[$i])[0]);
		oci_execute($participants) or die("No execute!");
		$rparticipants = oci_fetch_array($participants, OCI_ASSOC);
		if ($rparticipants) {
				$err = 1;
				echo 'Є така команда';
		}
	}
}


$value_data_started = date_format(date_create($_POST['tournament_data_started']),"d-M-Y ");
$value_data_end = date_format(date_create($_POST['tournament_data_end']),"d-M-Y ");
$today = date("d-M-Y"); 

//перевірка чи дати нормально накладаються
if ($err == 0 ){
	if (($value_data_started < $today) or ($value_data_end < $value_data_started)){
		$err = 1;
		echo 'Поганий часовий інтервал';
			
	}
}


if (!$rtournament and $err == 0) {
	
	//$value_id = rand( 1000000, 9999999);

	$counttourn = oci_parse($connect, 'Select count(*) from Tournament_for_admin where ORG_LOGIN_FK = :login
										GROUP BY ORG_LOGIN_FK');
	oci_bind_by_name($counttourn , ":login", $_COOKIE['login']);
	oci_execute($counttourn);
	$count = oci_fetch_array($counttourn , OCI_ASSOC);
	if (!$count) {$value_id1 = 0;}
	else {foreach ($count as $value_id1){}}
	$value_id = $value_id1 + 1;
	$value_organizer = $_COOKIE['login'];
	$value_name = $_POST['tournament_name'];
	$value_data_started = date_format(date_create($_POST['tournament_data_started']),"d-M-Y");
	$value_data_end = date_format(date_create($_POST['tournament_data_end']),"d-M-Y");
	
	$insert = 'INSERT INTO tournament_for_create(tourn_id, org_login_fk, tourn_name, tourn_data_started, tourn_data_end, tourn_del) '.
				'VALUES(:id, :organizer, :name, :data_start, :data_end, :del)';

	$compiled = oci_parse($connect, $insert);
	oci_bind_by_name($compiled, ':id', $value_id);
	oci_bind_by_name($compiled, ':organizer', $value_organizer);
	oci_bind_by_name($compiled, ':name', $value_name);
	oci_bind_by_name($compiled, ':data_start', $value_data_started);
	oci_bind_by_name($compiled, ':data_end', $value_data_end);
	$del = 0;
	oci_bind_by_name($compiled, ':del', $del);
	oci_execute($compiled);
	oci_commit($connect);
	
	
	
	for($i = 0; $i < $arr_length - 1; $i++){
		$value_name_team = explode(",", $teams[$i])[0];
		$value_email = (explode(",", $teams[$i])[1]);
		$value_email_team = substr($value_email, 0, -1);
		$insertteam = 'INSERT INTO Team_for_create(tm_name, tm_email) '.
				'VALUES(:name_team, :email_team)';
		$compiled = oci_parse($connect, $insertteam);
		oci_bind_by_name($compiled, ':name_team', $value_name_team);
		oci_bind_by_name($compiled, ':email_team', $value_email_team);
		oci_execute($compiled);
		oci_commit($connect);
	}
	
	oci_free_statement($tournament);
	oci_free_statement($participants);
	oci_close($connect);
	
	header("Location: personalpage.php"); exit;
}
else{
	oci_close($connect);
	echo '<form action="newtournament.php">
			<button type="submit">Добре(</button>
		</form>';
	//header("Location: newtournament.php"); exit;
}

?>
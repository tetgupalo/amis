<?php
if(!isset($_COOKIE['login'])){
    header("Location: main.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

    <!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<link rel="stylesheet" href="css/stylebut.css">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="personalpage.php">Personal Page
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
           <!-- <li class="nav-item">
              <a class="nav-link" href="#">Sign up</a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="Logout.php">Sign out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<section>
		<a href="personalpage.php"><button class="btn btn-green btn-fill-vert">MY TOURNAMENTS</button></a>
		<a href="newtournament.php"><button class="btn btn-green btn-fill-vert">NEW TOURNAMENT</button></a>
		<a href="message.php"><button class="btn btn-green btn-fill-vert">NEW MESSAGE</button></a>
	</section>
	
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5"><?php echo '<b>'.$_POST['nameteam1'].'</b> '.' <font color="BC0407"><b>VS </b></font><b>'.$_POST['nameteam2'].
									'</b> ('.$_POST['goalteam1'].' : '.$_POST['goalteam2'].')';?></h1>
    <?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		
		if (strcasecmp($_POST['action'], 'details') == 0 ) {
			echo '<h2 class="mt-5">LIST OF GOALS</h2>';
			$goallist = oci_parse($connect, 'SELECT SCORE_FOR_ADMIN.Gl_time, SCORE_FOR_ADMIN.tm_goal
										FROM SCORE_FOR_ADMIN
										WHERE SCORE_FOR_ADMIN.tm1_email_fk = :team1 
										and SCORE_FOR_ADMIN.tm2_email_fk = :team2 and SCORE_FOR_ADMIN.GM_DATA_FK = :datematch and gl_del = :del');
			$del = 0;						
			oci_bind_by_name($goallist, ":team1", $_POST['emailteam1']);
			oci_bind_by_name($goallist, ":team2", $_POST['emailteam2']);
			oci_bind_by_name($goallist, ":del", $del);
			oci_bind_by_name($goallist, ":datematch", $_POST['datamatch']);
			oci_execute($goallist);
			
			//foreach ($list as $everygoal){
			//	echo '<hr><font color="317E0E"><b>Time Goal: </b></font>'.$everygoal[1][0].'<font color="BC0407"><b>Who scored: </b></font><b>'.$everygoal[1][1].'</b><br>';	
			//}
			$i = 0;
			$matches = array();
			while ($list = oci_fetch_array($goallist, OCI_ASSOC)) {
				$j = 0;
				foreach ($list as $item) {
					if($item !== null) $matches[$i][$j] = (htmlentities($item, ENT_QUOTES));
					$j++;
				}
				$i++;
			}
			for ($i = 0; $i < count($matches); $i++){
				if (strcasecmp($matches[$i][1], $_POST['emailteam1']) == 0) {
					$nameteam = $_POST['nameteam1'];
				} else
				{
					$nameteam = $_POST['nameteam2'];
				}
				echo '<hr><font color="4682B4"><b>Time Goal: </b></font>'.$matches[$i][0].'<font color="4682B4"><b>		Who scored: </b></font>'.$nameteam.'<br>';
			}

			oci_free_statement($goal1ist);
			oci_close($connect);
		} else if (strcasecmp($_POST['action'], 'delete') == 0 ) {
			echo '<div class="form">
						<form  action="deletematch.php" method="POST" id="tryitForm">
							<fieldset>
							<div class="form-group">
								<hr>
								<label for="user">Input your password</label>
								<input type="password" name="organizer_password" pattern=".{8,30}$" title="This value is not valid" class="form-control" align="center" placeholder="password" id="name" required/>
							</div>			
							<div class="form-group">
								 <input class="btn btn-blue btn-fill-vert" type="submit" name="action" value="delete" />
								 <input name="email1" type="hidden" class="form-control" value="'.$_POST['emailteam1'].'" required/>
								 <input name="email2" type="hidden" class="form-control" value="'.$_POST['emailteam2'].'" required/>
								 <input name="datamatch" type="hidden" class="form-control" value="'.$_POST['datamatch'].'" required/>
							</div>
							</fieldset>
						</form>			
					</div>';
			oci_close($connect);
		}

	?>	
	</div>
    <!-- /.container -->
	
	
  </body>

</html>
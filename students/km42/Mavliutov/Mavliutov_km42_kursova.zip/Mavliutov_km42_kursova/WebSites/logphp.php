<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php //require 'checkstatus.php'; ?>

<?php
session_start();//начать новий, або продовжити сеанс роботи
if (isset($_POST['organizer_login']) && isset($_POST['organizer_password'])) {	
	
	require('connect.php');

  $select = oci_parse($connect, 'select *
                      from   Organizer_for_login
                      where  org_login = :new_login
                      and    org_pass = :new_pass and org_del = :del and org_admin =:adm');
  oci_bind_by_name($select, ":new_login", $_POST['organizer_login']);
  $admin = 0;
  $del = 0;
  oci_bind_by_name($select, ":del", $del);
  oci_bind_by_name($select, ":adm", $admin);
  oci_bind_by_name($select, ":new_pass", $_POST['organizer_password']);
  oci_execute($select);
  $r = oci_fetch_array($select, OCI_ASSOC);
  if ($r) {
    // The password matches: the user can use the application

    // Set the user name to be used as the client identifier in
    // future HTTP requests:
    $_SESSION['organizer_login'] = $_POST['organizer_login'];
	
	setcookie('login', $_POST['organizer_login'], time() + (86400 * 30), "/");
	oci_free_statement($select);
	oci_close($connect);
	header("Location: personalpage.php"); exit;
  }
 
  $selectadmin = oci_parse($connect, 'select *
                      from   Organizer_for_login
                      where  org_login = :new_login
                      and    org_pass = :new_pass and org_del = :del and org_admin =:adm');
  oci_bind_by_name($selectadmin, ":new_login", $_POST['organizer_login']);
  $admin = 1;
  $del = 0;
  oci_bind_by_name($selectadmin, ":del", $del);
  oci_bind_by_name($selectadmin, ":adm", $admin);
  oci_bind_by_name($selectadmin, ":new_pass", $_POST['organizer_password']);
  oci_commit($connect);
  oci_execute($selectadmin);
  $a = oci_fetch_array($selectadmin, OCI_ASSOC);
  if ($a) {
    $_SESSION['organizer_login'] = $_POST['organizer_login'];
	
	setcookie('login', $_POST['organizer_login'], time() + (86400 * 30), "/");
	setcookie('admin', $_POST['organizer_login'], time() + (86400 * 30), "/");
	oci_free_statement($selectadmin);
	oci_close($connect);
	header("Location: adminpage.php"); exit;
  } else {
	oci_free_statement($selectadmin);
	oci_close($connect);
	echo 'Спробуй ще раз';
		echo '<form action="login.php">
			<button type="submit">Добре(</button>
		</form>';
	//header("Location: login.php"); exit;
    // No rows matched so login failed
  }
}
?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php
date_default_timezone_set('Africa/Lagos');

session_start();//начать новий, або продовжити сеанс роботи	

$err = 0;
$havegoal = 1;
require('connect.php');

$org = $_COOKIE['login'];
$id = $_POST['id_tourn'];
$name1 = $_POST['name_team1'];
$name2 = $_POST['name_team2'];
$sdate =  date_format(date_create($_POST['matchdate']),"d-M-Y ");

$datateams  = $_POST['listgoals'];
$teams = explode("\n", $datateams);
//valid = preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) ([0-1][0-9]|2[0-4]):([0-6][0-9])$/",$date);
$arr_length = count($teams);
if (strcasecmp($datateams, '0') != 0){
	for($i = 0; $i < $arr_length - 1; $i++) {
		if (count(explode(",", $teams[$i])) != 2 ){
			$err = 1;
			echo 'погано ввели дані';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
			break;
		}
		$date = explode(",", $teams[$i])[1];
		if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) ([0-1][0-9]|2[0-4]):([0-6][0-9])$/",substr($date, 0, -1))) {
			$err = 1;
			echo 'З мейлом не то';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
			break;
		}
		if((!strcasecmp(explode(",", $teams[$i])[0], $name1) == 0) and (!strcasecmp(explode(",", $teams[$i])[0], $name2) == 0)){
			$err = 1;
			echo 'Шось ви з командами помилились';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
			break;
		}
	}
}else $havegoal = 0;
//перевірка чи є команди в базі
if ($err == 0 ){
	$part1 = oci_parse($connect, 'select tm_email
				from   Team_for_admin
				where  tm_name =:new_tm_name');
	oci_bind_by_name($part1, ":new_tm_name", $name1);
	oci_execute($part1) or die("No execute!");
	$rpart1 = oci_fetch_array($part1, OCI_ASSOC);
	if (!$rpart1) {
			$err = 1;
			echo 'Шось ви з командами помилились';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	} else {foreach ($rpart1 as $email1){}}
	
	$part2 = oci_parse($connect, 'select tm_email
				from   Team_for_admin
				where  tm_name =:new_tm_name');
	oci_bind_by_name($part2, ":new_tm_name", $name2);
	oci_execute($part2) or die("No execute!");
	$rpart2 = oci_fetch_array($part2, OCI_ASSOC);
	if (!$rpart2) {
			$err = 1;
			echo 'Шось ви з командами помилились';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	} else {foreach ($rpart2 as $email2){}}
}

//перевірка чи дати нормально накладаються
if ($err == 0 ){
	$part1 = oci_parse($connect, 'select tourn_data_started, tourn_data_end
				from   Tournament_for_admin
				where  tourn_id =:new_id and org_login_fk = :new_org and tourn_del =:del');
	oci_bind_by_name($part1, ":new_org", $org);
	oci_bind_by_name($part1, ":new_id", $id);
	$del = 0;
	oci_bind_by_name($part1, ":del", $del);
	oci_execute($part1) or die("No execute!");
	$rpart1 = oci_fetch_array($part1, OCI_ASSOC);
	$data = array();
	$i=0;
	foreach ($rpart1 as $item){
		if($item !== null) $data[$i] = (htmlentities($item, ENT_QUOTES));
		$i++;
	}
	if ((strtotime($data[0])>strtotime($sdate)) or (strtotime($data[1])<strtotime($sdate))){
		$err = 1;
		echo 'Не в рамках турніру';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	}
	if (strcasecmp($datateams, '0') != 0){
		for($i = 0; $i < $arr_length - 1; $i++) {
			if (date_format(date_create(explode(",", $teams[$i])[1]),"d-M-Y ") != $sdate ){
				$err = 1;
				echo 'Час голу не той(';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
				break;
			}
		}
	}
}

if ($err == 0) {
	
	/*$email1
	$email2
	$org = $_COOKIE['login'];
	$id = $_POST['id_tourn'];
	$sdate =  date_format(date_create($_POST['matchdate']),"d-M-Y ");*/
	
	$insert = 'INSERT INTO game_for_admin(tourn_id_fk, org_login_fk, tm1_email_fk, tm2_email_fk, gm_data, gm_del) '.
				'VALUES(:id, :orgname, :em1, :em2, :datam, :del)';
	$compiled = oci_parse($connect, $insert);
	oci_bind_by_name($compiled, ':em1', $email1);
	oci_bind_by_name($compiled, ':em2', $email2);
	oci_bind_by_name($compiled, ':orgname', $org);
	oci_bind_by_name($compiled, ':id', $id);
	oci_bind_by_name($compiled, ':datam', $sdate);
	$del = 0;
	oci_bind_by_name($compiled, ':del', $del);
	oci_execute($compiled);
	oci_commit($connect);
	
	if ($havegoal !=0 ){
		for($i = 0; $i < $arr_length - 1; $i++){
			$goaltime = date_format(date_create(explode(",", $teams[$i])[1]),"d-M-Y H:i:s");
			//$email1
			//$email2
			//$sdate
			if (strcasecmp(explode(",", $teams[$i])[0],$name1) == 0){
				$tmgoal = $email1;
			}
			else $tmgoal = $email2;
			$insertteam = 'INSERT INTO Score_for_admin(gl_time, tm1_email_fk, tm2_email_fk, gm_data_fk, tm_goal, gl_del) '.
					'VALUES(:goaltime, :email_team1, :email_team2, :datematch, :teamgoal, :del)';
			$compiled = oci_parse($connect, $insertteam);
			oci_bind_by_name($compiled, ':goaltime', $goaltime);
			oci_bind_by_name($compiled, ':email_team1', $email1);
			oci_bind_by_name($compiled, ':email_team2', $email2);
			oci_bind_by_name($compiled, ':datematch', $sdate);
			oci_bind_by_name($compiled, ':teamgoal', $tmgoal);
			$del = 0;
			oci_bind_by_name($compiled, ':del', $del);
			oci_execute($compiled);
			oci_commit($connect);
		}
	}
	oci_free_statement($part1);
	oci_free_statement($part2);
	oci_close($connect);
	$_POST['action'] =  'details';
	header("Location: personalpage.php"); exit;
}
else{
	$_POST['action'] =  'details';
	oci_close($connect);
	//header("Location: personalpage.php"); exit;
}

//до кінця перевірки, вставку в голи, тригери


?>

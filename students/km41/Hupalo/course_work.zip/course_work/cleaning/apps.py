from django.apps import AppConfig


class CleaningConfig(AppConfig):
    name = 'cleaning'

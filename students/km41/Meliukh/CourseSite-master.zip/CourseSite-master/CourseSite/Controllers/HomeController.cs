﻿using CourseSite.Models;
using CourseSite.ViewModels;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;



namespace CourseSite.Controllers
{
    public class HomeController : Controller
    {
        ApplicationUserManager _userManager;
        [Authorize]
        public ActionResult Index()
        {
            _userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();

            ApplicationUser user = _userManager.FindByEmail(User.Identity.Name);
            if (user != null)
            {
                var roles = _userManager.GetRoles(user.Id);
                if (roles.Contains("notconfirmed"))
                {
                    return Redirect("/Home/Notauth");
                }
            }
          
            //implement database work
            var model = new HomeViewModel { Role = _userManager.GetRoles(user.Id).FirstOrDefault().ToString(),
                                            Group = "some group", Name = "Jhon Doe" };
            if (user.IsTeacher)
            {
                return View("IndexForTeacher");
            }
            return View("IndexForStudent", model);
        }

        [Authorize(Roles = "notconfirmed")]
        public ActionResult Notauth()
        {
            return View();
        }

        public ActionResult Adminpanel()
        {
            _userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();

            var users = _userManager.Users
                .AsNoTracking()
                .ToList();
            List<AdminPanelViewModel> result = new List<AdminPanelViewModel>();
            foreach (var u in users)
            {
                var roles = _userManager.GetRoles(u.Id);
                if (roles.Contains("notconfirmed"))
                    result.Add(new AdminPanelViewModel { UserEmail = u.Email, UserName = u.UserName});
            }

            return View("Contact", result);
        }
    }
}
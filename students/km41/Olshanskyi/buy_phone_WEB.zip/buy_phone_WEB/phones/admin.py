from django.contrib import admin
from .models import Phone

admin.site.register(Phone)

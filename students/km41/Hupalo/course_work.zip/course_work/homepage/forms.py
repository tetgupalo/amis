from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class AuthForm(UserCreationForm):
    first_name = forms.CharField(max_length=55, required=False)
    last_name = forms.CharField(max_length=55, required=False)
    email = forms.EmailField(max_length=255, widget=forms.TextInput(attrs={'class':'validate', 'pattern':"[A-Za-z0-9._]+@[A-Za-z0-9._]+\.[A-Za-z]{2,5}", 'title': "valid_email@mail.com"}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', )
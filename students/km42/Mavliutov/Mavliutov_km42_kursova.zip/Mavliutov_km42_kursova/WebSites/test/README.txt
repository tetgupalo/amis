A Pen created at CodePen.io. You can find this one at https://codepen.io/chrisdothtml/pen/waKBdM.

 A collection of various types of CSS buttons in various colors.
from django.conf.urls import url
from .views import AllCleaning, CleaningDetails, CleanerDetails, OrderDetails, UserOrderDetails

urlpatterns = [

	url(r'^all/$', AllCleaning.as_view(),
		name='all_cleaning'),

	url(r'^details/(?P<pk>\d+)/$', CleaningDetails.as_view(),
		name='cleaning_details'),

	url(r'^cleaner/(?P<pk>\d+)/$', CleanerDetails.as_view(),
		name='cleaner_details'),

	url(r'^order_of_user/(?P<pk>\d+)/$', UserOrderDetails.as_view(),
		name='order_of_user'),

	url(r'^order/details/(?P<pk>\d+)/$', OrderDetails.as_view(),
		name='order_details'),

]

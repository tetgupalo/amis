<?php
if(isset($_COOKIE['login'])){
	if(isset($_COOKIE['admin'])){
		header("Location: adminpage.php"); exit;
	}
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

	<!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	

  </head>

  <body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#ex2">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Sign up</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Sign in</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Page Content -->
    <div class="container">
           <h2 class="mt-4">Are you ready to manage the football tournaments?</h2>
		   <h2 class="mt-5">&nbsp;</h2>
      <h4 class="mt-4">Join millions of users who already trust Challonge to manage their tournaments. More than 3 tournaments have already been created.</h4>

	<div class="form">
			<form  action="mainfilter.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="filter"><b>Search Tournament</b></label>
					<input type="text" name="filter1_tournament_name" pattern="^([A-z0-9,A-z0-9]{1,30})$" title="This value is not valid" class="form-control" placeholder="Tournament name" required/>
				</div>			
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >SEARCH<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
	</div>
	
	<?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		require('connect.php');
		

		/*$countmytourn = oci_parse($connect, 'SELECT getcountmainfilter(:filters) FROM dual');
		$filt =  mb_strtolower($_POST['filter_tournament_name'])."%";
		oci_bind_by_name($countmytourn, ":filters", $filt);
		oci_execute($countmytourn);
		$row = oci_fetch_array($countmytourn, OCI_ASSOC);
		if (!$row) {$mycount = 0;}
		else {foreach ($row as $mycount){}}
		echo '<h3 class="mt-5">'.$mycount.' RESULTS</h3>';	*/
		
		$vibyr = explode(",", $_POST['filter1_tournament_name']);
		$filt1 =  mb_strtolower($vibyr[0])."%";
		$filt2 =  mb_strtolower($vibyr[1])."%";
		$stid = oci_parse($connect, 'SELECT * FROM TABLE(filters.get_tab(:filter1, :filter2))');
		oci_bind_by_name($stid, ":filter1", $filt1);
		oci_bind_by_name($stid, ":filter2", $filt2);
		oci_execute($stid);
		$i = 0;
		$tourns = array();
		while ($row = oci_fetch_array($stid, OCI_ASSOC)) {
			$j = 0;
			foreach ($row as $item) {
				if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
				$j++;
			}
			$i++;
		}
		for ($i = 0; $i < count($tourns); $i++) {
			$name = $tourns[$i][1];
			$id = $tourns[$i][0];
			$nametourn = $tourns[$i][2];
			echo '<hr><font color="317E0E"><b>Name Tournament: </b></font>'.$tourns[$i][2].'<br>'.' <font color="317E0E"><b>Start Date: </b></font>'.$tourns[$i][3].'<br>'.' <font color="317E0E"><b>End Date: </b></font>'.$tourns[$i][4].'<br>'.'
				 <form method="POST" action="abouttournamentmain.php">
				 <input name="id_tourn" type="hidden" class="form-control" value="'.$id.'" required/>
				 <input name="org_login" type="hidden" class="form-control" value="'.$name.'" required/>	 
				 <input name="tourn_n" type="hidden" class="form-control" value="'.$nametourn.'" required/>	
				 <button class="btn btn-blue btn-fill-vert">more details</button>
				 </form> ';
		}
		oci_free_statement($countmytourn);
		oci_free_statement($stid);
		oci_close($connect);
	?>
	
	
<section id="ex2">

	
</section>
	
	
	
	</div>

  </body>

</html>
﻿namespace Coursework1
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btstores = new System.Windows.Forms.Button();
            this.btcompsinstores = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Registration";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(13, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Computers";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btstores
            // 
            this.btstores.Location = new System.Drawing.Point(13, 73);
            this.btstores.Name = "btstores";
            this.btstores.Size = new System.Drawing.Size(125, 23);
            this.btstores.TabIndex = 2;
            this.btstores.Text = "Stores";
            this.btstores.UseVisualStyleBackColor = true;
            this.btstores.Click += new System.EventHandler(this.btstores_Click);
            // 
            // btcompsinstores
            // 
            this.btcompsinstores.Location = new System.Drawing.Point(13, 102);
            this.btcompsinstores.Name = "btcompsinstores";
            this.btcompsinstores.Size = new System.Drawing.Size(125, 23);
            this.btcompsinstores.TabIndex = 3;
            this.btcompsinstores.Text = "Comp. in stores";
            this.btcompsinstores.UseVisualStyleBackColor = true;
            this.btcompsinstores.Click += new System.EventHandler(this.btcompsinstores_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(13, 136);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(175, 171);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btcompsinstores);
            this.Controls.Add(this.btstores);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Admin";
            this.Text = "Admin";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btstores;
        private System.Windows.Forms.Button btcompsinstores;
        private System.Windows.Forms.Button button3;
    }
}
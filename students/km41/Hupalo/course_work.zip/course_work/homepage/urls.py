from django.conf.urls import url
from django.contrib.auth import views as authentificate

from . import views


urlpatterns = [

    url(r'^$', views.home, name='home'),

    url(r'^login/$', authentificate.login, {'template_name': 'login.html'}, name='login'),

    url(r'^logout/$', authentificate.logout,{'next_page': '/'}, name='logout'),

    url(r'^signup/$', views.signup, name='signup'),

]

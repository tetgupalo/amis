/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     29.10.2017 18:50:02                          */
/*==============================================================*/


/*alter table Game
   drop constraint FK_GAME_AWAY_TEAM_TEAM;

alter table Game
   drop constraint FK_GAME_HOME_TEAM_TEAM;

alter table Game
   drop constraint FK_GAME_TOURNAMEN_TOURNAME;

alter table Messages
   drop constraint FK_MESSAGES_ORGANIZER_ORGANIZE;

alter table Messages
   drop constraint FK_MESSAGES_READ_TEAM;

alter table Score
   drop constraint FK_SCORE_GOAL_IN_M_GAME;

alter table Tournament
   drop constraint FK_TOURNAME_ORGANIZE__ORGANIZE;

drop index Away_Team_play_FK;

drop index Home_Team_play_FK;

drop index Tournament_contains_games_FK;

drop table Game cascade constraints;

drop index Read_FK;

drop index Organizer_sends_message_FK;

drop table Messages cascade constraints;

drop table Organizer cascade constraints;

drop index Goal_in_game_FK;

drop table Score cascade constraints;

drop table Team cascade constraints;

drop index Organize_create_tournament_FK;

drop table Tournament cascade constraints;*/

/*==============================================================*/
/* Table: Organizer                                             */
/*==============================================================*/
create table Organizer 
(
   Organizer_login      VARCHAR2(30)         not null,
   Organizer_email      VARCHAR2(50)         not null,
   Organizer_password   VARCHAR2(30)         not null,
   Organizer_admin      NUMBER(1)            not null,
   Organizer_del        NUMBER(1)            not null,
   constraint PK_ORGANIZER primary key (Organizer_login)
);

ALTER TABLE Organizer
ADD CONSTRAINT email_org_unique UNIQUE (Organizer_email);

ALTER TABLE Organizer
ADD CONSTRAINT check_name_organ CHECK(REGEXP_LIKE(Organizer_login, '^[A-z0-9_.]{8,30}$'));

ALTER TABLE Organizer
ADD CONSTRAINT check_pass_organ_len CHECK (length(Organizer_password)>=8 AND length(Organizer_password)<=30);

ALTER TABLE Organizer
ADD CONSTRAINT check_email_organ CHECK(REGEXP_LIKE(Organizer_email, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Organizer
ADD CONSTRAINT check_email_organ_len CHECK((length(Organizer_email)>=8 AND length(Organizer_email)<=50));

ALTER TABLE Organizer
ADD CONSTRAINT check_org_admin CHECK((organizer_admin = 0) or (organizer_admin = 1));

ALTER TABLE Organizer
ADD CONSTRAINT check_org_del CHECK((organizer_del = 0) or (organizer_del = 1));
/*==============================================================*/
/* Table: Tournament                                            */
/*==============================================================*/
create table Tournament 
(
   Tournament_id        INTEGER              not null,
   Organizer_login_fk   VARCHAR2(30)         not null,
   Tournament_name      VARCHAR2(10)         not null,
   Tournament_data_started DATE              not null,
   Tournament_data_end  DATE                 not null,
   Tournament_del       NUMBER(1)            not null,
   constraint PK_TOURNAMENT primary key (Tournament_id, Organizer_login_fk)
);

ALTER TABLE Tournament
ADD CONSTRAINT tourn_unique UNIQUE (Tournament_name, Tournament_data_started);

ALTER TABLE Tournament
ADD CONSTRAINT check_id_tourn CHECK (REGEXP_LIKE(Tournament_id, '^\d+$'));

ALTER TABLE Tournament
ADD CONSTRAINT check_id_tourn_len CHECK ((Tournament_id > 0) AND (Tournament_id < 2147483647));

ALTER TABLE Tournament
ADD CONSTRAINT check_name_organ_tourn CHECK(REGEXP_LIKE(Organizer_login_fk, '^[A-z0-9_.]{8,30}$'));

ALTER TABLE Tournament
ADD CONSTRAINT check_name_tourn CHECK(REGEXP_LIKE(Tournament_name, '^[A-z0-9]{5,10}$'));

ALTER TABLE Tournament
ADD CONSTRAINT check_date_end1_tourn CHECK(Tournament_data_end >= Tournament_data_started);

ALTER TABLE Tournament
ADD CONSTRAINT check_tourn_del CHECK((tournament_del = 0) or (tournament_del = 1));

/*==============================================================*/
/* Table: Game                                                 */
/*==============================================================*/
create table Game
(
   Game_data           DATE                 not null,
   Team1_email_fk       VARCHAR2(50)         not null,
   Team2_email_fk       VARCHAR2(50)         not null,
   Tournament_id_fk     INTEGER              not null,
   Organizer_login_fk   VARCHAR2(30)         not null,
   Game_del             NUMBER(1)            not null,
   constraint PK_GAME primary key (Team1_email_fk, Team2_email_fk, Game_data)
);


/* start_tournament < match_date < end_tournament */

ALTER TABLE Game
ADD CONSTRAINT check_id_tourn_game CHECK ( REGEXP_LIKE(Tournament_id_fk, '^\d+$'));

ALTER TABLE Game
ADD CONSTRAINT check_id_tourn_game_len CHECK ((Tournament_id_fk > 0) AND (Tournament_id_fk < 2147483647));

ALTER TABLE Game
ADD CONSTRAINT check_name_organ_game CHECK(REGEXP_LIKE(Organizer_login_fk, '^[A-z0-9_.]{8,30}$'));

ALTER TABLE Game
ADD CONSTRAINT check_email_team1_game CHECK(REGEXP_LIKE(Team1_email_fk, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Game
ADD CONSTRAINT check_email_team1_game_len CHECK((length(Team1_email_fk)>=8 AND length(Team1_email_fk)<=50));

ALTER TABLE Game
ADD CONSTRAINT check_email_team2_game CHECK(REGEXP_LIKE(Team2_email_fk, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Game
ADD CONSTRAINT check_email_team2_game_len CHECK((length(Team2_email_fk)>=8 AND length(Team2_email_fk)<=50));

ALTER TABLE Game
ADD CONSTRAINT check_game_del CHECK((game_del = 0) or (game_del = 1));

/*==============================================================*/
/* Index: Tournament_contains_games_FK                        */
/*==============================================================*/
create index Tournament_contains_games_FK on Game (
   Tournament_id_fk ASC,
   Organizer_login_fk ASC
);

/*==============================================================*/
/* Index: Home_Team_play_FK                                     */
/*==============================================================*/
create index Home_Team_play_FK on Game (
   Team2_email_fk ASC
);

/*==============================================================*/
/* Index: Away_Team_play_FK                                     */
/*==============================================================*/
create index Away_Team_play_FK on Game (
   Team1_email_fk ASC
);

/*==============================================================*/
/* Table: Messages                                              */
/*==============================================================*/
create table Messages 
(
   Message_data         DATE                 not null,
   Team_email_fk        VARCHAR2(50)         not null,
   Organizer_login_fk   VARCHAR2(30)         not null,
   Message_context      CLOB                 not null,
   constraint PK_MESSAGES primary key (Team_email_fk, Organizer_login_fk, Message_data)
);

/*ALTER TABLE Messages */ 
/*ADD CONSTRAINT check_data_mess CHECK (CAST(Message_data as date) <= CAST(GETDATE() as date));*/
/* IT DOES TRIGGER*/


ALTER TABLE Messages 
ADD CONSTRAINT check_mess_len CHECK((length(Message_context)>=2 AND length(Message_context)<=40));

ALTER TABLE Messages 
ADD CONSTRAINT check_email_team_mess CHECK(REGEXP_LIKE(Team_email_fk, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Messages 
ADD CONSTRAINT check_email_team_mess_len CHECK((length(Team_email_fk)>=8 AND length(Team_email_fk)<=50));

ALTER TABLE Messages 
ADD CONSTRAINT check_name_organ_mess CHECK(REGEXP_LIKE(Organizer_login_fk, '^[A-z0-9_.]{8,30}$'));

/*==============================================================*/
/* Index: Organizer_sends_message_FK                            */
/*==============================================================*/
create index Organizer_sends_message_FK on Messages (
   Organizer_login_fk ASC
);

/*==============================================================*/
/* Index: Read_FK                                               */
/*==============================================================*/
create index Read_FK on Messages (
   Team_email_fk ASC
);

/*==============================================================*/
/* Table: Score                                                 */
/*==============================================================*/
create table Score 
(
   Goal_time            TIMESTAMP            not null,
   Team1_email_fk       VARCHAR2(50)         not null,
   Team2_email_fk       VARCHAR2(50)         not null,
   Game_data_fk        DATE                 not null,
   Team_goal            VARCHAR2(50)         not null,
   Goal_del             NUMBER(1)            not null,
   constraint PK_SCORE primary key (Team1_email_fk, Team2_email_fk, Game_data_fk, Goal_time)
);

/*ALTER TABLE Score
ADD CONSTRAINT check_time_goal_score CHECK ((CAST(Game_data_fk AS DATE) = CAST(Goal_time AS DATE)));*/
/* IT DOES TRIGGER*/

ALTER TABLE Score
ADD CONSTRAINT check_name_goal_score CHECK(REGEXP_LIKE(Team_goal, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Score
ADD CONSTRAINT check_name_goal_score_len CHECK((length(Team_goal)>=8 AND length(Team_goal)<=50));

ALTER TABLE Score
ADD CONSTRAINT check_email_team1_score CHECK(REGEXP_LIKE(Team1_email_fk, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Score
ADD CONSTRAINT check_email_team1_score_len CHECK((length(Team1_email_fk)>=8 AND length(Team1_email_fk)<=50));

ALTER TABLE Score
ADD CONSTRAINT check_email_team2_score CHECK(REGEXP_LIKE(Team2_email_fk, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Score
ADD CONSTRAINT check_email_team2_score_len CHECK((length(Team2_email_fk)>=8 AND length(Team2_email_fk)<=50));

ALTER TABLE Score
ADD CONSTRAINT check_goal_del CHECK((goal_del = 0) or (goal_del = 1));

/*==============================================================*/
/* Index: Goal_in_game_FK                                      */
/*==============================================================*/
create index Goal_in_game_FK on Score (
   Team1_email_fk ASC,
   Team2_email_fk ASC,
   Game_data_fk ASC
);

/*==============================================================*/
/* Table: Team                                                  */
/*==============================================================*/
create table Team 
(
   Team_email           VARCHAR2(50)         not null,
   Team_name            VARCHAR2(30)         not null,
   constraint PK_TEAM primary key (Team_email)
);

ALTER TABLE Team
ADD CONSTRAINT team_name_unique UNIQUE (Team_name);

ALTER TABLE Team
ADD CONSTRAINT check_name_team CHECK(REGEXP_LIKE(Team_name, '^[A-z0-9]{8,30}$'));

ALTER TABLE Team
ADD CONSTRAINT check_email_team CHECK(REGEXP_LIKE (Team_email, '^[A-z0-9_.]+@([A-z]{2,6}+\.)+[A-z]{2,6}$'));

ALTER TABLE Team
ADD CONSTRAINT check_email_team_len CHECK((length(Team_email)>=8 AND length(Team_email)<=50));

/*==============================================================*/
/* Index: "Organize_create_ tournament_FK"                      */
/*==============================================================*/
create index Organize_create_tournament_FK on Tournament (
   Organizer_login_fk ASC
);

alter table Game
   add constraint FK_GAME_AWAY_TEAM_TEAM foreign key (Team1_email_fk)
      references Team (Team_email);

alter table Game
   add constraint FK_GAME_HOME_TEAM_TEAM foreign key (Team2_email_fk)
      references Team (Team_email);

alter table Game
   add constraint FK_GAME_TOURNAMEN_TOURNAME foreign key (Tournament_id_fk, Organizer_login_fk)
      references Tournament (Tournament_id, Organizer_login_fk);

alter table Messages
   add constraint FK_MESSAGES_ORGANIZER_ORGANIZE foreign key (Organizer_login_fk)
      references Organizer (Organizer_login);

alter table Messages
   add constraint FK_MESSAGES_READ_TEAM foreign key (Team_email_fk)
      references Team (Team_email);

alter table Score
   add constraint FK_SCORE_GOAL_IN_M_GAME foreign key (Team1_email_fk, Team2_email_fk, Game_data_fk)
      references Game (Team1_email_fk, Team2_email_fk, Game_data);

alter table Tournament
   add constraint FK_TOURNAME_ORGANIZE__ORGANIZE foreign key (Organizer_login_fk)
      references Organizer (Organizer_login);


/* views */

CREATE OR REPLACE VIEW Organizer_for_admin
AS
SELECT Organizer_login as Org_login, Organizer_email AS Org_email, Organizer_admin as Org_admin, Organizer_del As org_del
FROM Organizer;

CREATE OR REPLACE VIEW Organizer_for_login
AS
SELECT Organizer_login as Org_login, Organizer_password AS Org_pass, Organizer_admin as org_admin, organizer_del as org_del
FROM Organizer;

CREATE OR REPLACE VIEW Organizer_for_register
AS
SELECT Organizer_login as Org_login, Organizer_password AS Org_pass, Organizer_email AS Org_email, organizer_admin as org_admin, organizer_del as org_del
FROM Organizer;

CREATE OR REPLACE VIEW Tournament_for_admin
AS
SELECT Tournament_id as Tourn_id, Organizer_login_fk AS Org_login_fk, Tournament_name AS Tourn_name,
	Tournament_data_started AS Tourn_data_started, Tournament_data_end AS Tourn_data_end, Tournament_del AS tourn_del
FROM Tournament;

CREATE OR REPLACE VIEW Tournament_for_create
AS
SELECT Tournament_id as Tourn_id, Organizer_login_fk AS Org_login_fk, Tournament_name AS Tourn_name,
	Tournament_data_started AS Tourn_data_started, Tournament_data_end AS Tourn_data_end, Tournament_del AS tourn_del
FROM Tournament;


CREATE OR REPLACE VIEW Game_for_admin
AS
SELECT Game_data as Gm_data, Team1_email_fk AS Tm1_email_fk, Team2_email_fk  AS Tm2_email_fk,
	Tournament_id_fk AS Tourn_id_fk, Organizer_login_fk AS Org_login_fk, game_del AS gm_del
FROM Game;


CREATE OR REPLACE VIEW Msg_for_admin
AS
SELECT Message_data as Msg_data, Team_email_fk AS Tm_email_fk, Organizer_login_fk AS Org_login_fk, MESSAGE_context as msg_context
FROM Messages;


CREATE OR REPLACE VIEW Score_for_admin
AS
SELECT Goal_time as Gl_time, Team1_email_fk AS Tm1_email_fk, Team2_email_fk AS Tm2_email_fk,
	Game_data_fk AS Gm_data_fk, Team_goal AS Tm_goal, goal_del as gl_del
FROM Score;


CREATE OR REPLACE VIEW Team_for_admin
AS
SELECT Team_email as Tm_email, Team_name AS Tm_name
FROM Team;

CREATE OR REPLACE VIEW Team_for_create
AS
SELECT Team_email as Tm_email, Team_name AS Tm_name
FROM Team;



create or replace TRIGGER trg_check_goal_dates
  BEFORE INSERT OR UPDATE ON Score
  FOR EACH ROW
BEGIN
  IF( (:new.game_data_fk > :new.goal_time) or (:new.goal_time > (:new.game_data_fk + 1)))
  THEN
    RAISE_APPLICATION_ERROR( -20001, 
          'Invalid goal_time: goal_time must be greater than the current date - value = ' || 
          to_char( :new.goal_time, 'YYYY-MM-DD HH24:MI:SS' ) );
  END IF;
END;
/

create or replace FUNCTION CHECK_DATE_MATCH 
	(GAME_DATA IN DATE, ORG_LOGIN IN VARCHAR2, TOURN_ID IN INT ) 
	RETURN number 
AS
	counter number;
BEGIN
	Select count(*) into counter from tournament where organizer_login_fk = org_login and tournament_data_started <= game_data
		and tournament_data_end >= game_data and tournament_id = tourn_id;
	return counter;
END CHECK_DATE_MATCH;
/

create or replace TRIGGER trg_check_dates_match
  BEFORE INSERT ON Game
  FOR EACH ROW
declare
	counter number;
BEGIN
  select CHECK_DATE_MATCH(:new.game_data, :new.organizer_login_fk, :new.tournament_id_fk) into counter from dual;
  IF(counter = 0)
	THEN
		RAISE_APPLICATION_ERROR( -20001, 
          'Invalid date: Date must be greater than the current date - value = ' || 
          to_char( :new.game_data, 'YYYY-MM-DD HH24:MI:SS' ) );
  END IF;
END;
/

create or replace TRIGGER trg_check_dates
  BEFORE INSERT ON Tournament
  FOR EACH ROW
BEGIN
  IF( :new.Tournament_data_started <= SYSDATE )
  THEN
    RAISE_APPLICATION_ERROR( -20001, 
          'Invalid Tournament_data_started: Tournament_data_started must be greater than the current date - value = ' || 
          to_char( :new.Tournament_data_started, 'YYYY-MM-DD HH24:MI:SS' ) );
  END IF;
END;
/

create or replace TRIGGER trg_check_dates_msg
  BEFORE INSERT ON Messages
  FOR EACH ROW
BEGIN
  IF( :new.message_data <> TO_DATE(TO_CHAR(sysdate, 'MM/DD/YYYY'), 'MM/DD/YYYY'))
  THEN
    RAISE_APPLICATION_ERROR( -20001, 
          'Invalid date: Date must be greater than the current date - value = ' || 
          to_char( :new.message_data, 'YYYY-MM-DD HH24:MI:SS' ) );
  END IF;
END;
/

create or replace TRIGGER insertnewgoal
INSTEAD OF INSERT ON score_for_admin
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    INSERT INTO Score(goal_time, team1_email_fk, team2_email_fk, game_data_fk, team_goal, goal_del)
    VALUES(:NEW.gl_time, :NEW.tm1_email_fk, :NEW.tm2_email_fk, :NEW.gm_data_fk, :NEW.tm_goal, :NEW.gl_del);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER insertnewmatch
INSTEAD OF INSERT ON game_for_admin
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    INSERT INTO Game(game_data, team1_email_fk, team2_email_fk, tournament_id_fk, organizer_login_fk, game_del)
    VALUES(:NEW.gm_data, :NEW.tm1_email_fk, :NEW.tm2_email_fk, :NEW.tourn_id_fk, :NEW.org_login_fk, :NEW.gm_del);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER insertnewmess
INSTEAD OF INSERT ON msg_for_admin
FOR EACH ROW
begin
    INSERT INTO Messages(message_data, team_email_fk, organizer_login_fk, message_context)
    VALUES(:NEW.msg_data, :NEW.tm_email_fk, :NEW.org_login_fk, :NEW.msg_context);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER insertnewteam
INSTEAD OF INSERT ON Team_for_create
FOR EACH ROW
begin
    INSERT INTO Team(team_name, team_email)
    VALUES(:NEW.tm_name, :NEW.tm_email);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER insertnewtournament
INSTEAD OF INSERT ON Tournament_for_create
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    INSERT INTO Tournament(tournament_id, organizer_login_fk, tournament_name, tournament_data_started, tournament_data_end, tournament_del)
    VALUES(:NEW.tourn_id, :NEW.org_login_fk, :NEW.tourn_name, :NEW.tourn_data_started, :NEW.tourn_data_end, :NEW.tourn_del);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/


CREATE TRIGGER checkregistration
BEFORE INSERT ON Organizer
FOR EACH ROW
Declare
    dvd_rented  EXCEPTION;
    count_login NUMBER (1);
    count_email NUMBER (1);
begin
    SELECT COUNT (*)
    INTO count_login
    FROM Organizer
    WHERE organizer_login = :NEW.organizer_login;
    IF count_login > 0 THEN
        raise_application_error(20000, 'Sorry, this login reserved.');
    END IF;
    
    SELECT COUNT (*)
    INTO count_email
    FROM Organizer
    WHERE organizer_email = :NEW.organizer_email;
    IF count_email > 0 THEN
        raise_application_error(20000, 'Sorry, this email reserved.');
    END IF;
end;
/

create or replace TRIGGER insertdataregistration
INSTEAD OF INSERT ON Organizer_for_register
FOR EACH ROW
begin
	SET TRANSACTION READ WRITE;
    INSERT INTO Organizer(organizer_login, organizer_email, organizer_password, organizer_admin, organizer_del)
    VALUES(:NEW.org_login, :NEW.org_email, :NEW.org_pass, :NEW.org_admin, :NEW.org_del);
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER updatematch
INSTEAD OF UPDATE ON Game_for_admin
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    UPDATE Game SET game_del = :New.gm_del
    where team1_email_fk = :NEW.tm1_email_fk and team2_email_fk = :New.tm2_email_fk and game_data = :New.gm_data;
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER updateorganizer
INSTEAD OF UPDATE ON organizer_for_admin
FOR EACH ROW
begin
	SET TRANSACTION READ WRITE;
    UPDATE organizer SET organizer_del = :New.org_del
	where organizer_login = :NEw.org_login;
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER updatescore
INSTEAD OF UPDATE ON score_for_admin
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    UPDATE Score SET goal_del = :New.gl_del
	where team1_email_fk = :New.tm1_email_fk and team2_email_fk = :NEW.tm2_email_fk and game_data_fk = :New.gm_data_fk;
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TRIGGER updatetournament
INSTEAD OF UPDATE ON Tournament_for_admin
FOR EACH ROW
begin
	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    UPDATE TOURNAMENT SET TOURNament_NAME = :NEW.tourn_name, tournament_data_started = :NEW.tourn_data_started, 
    tournament_data_end = :NEW.tourn_data_end, tournament_del = :NEW.tourn_del
	where tournament_id = :NEW.tourn_id and ORGANIZER_LOGIN_fk = :NEW.org_login_fk;
EXCEPTION
	WHEN OTHERS THEN
		raise_application_error (-20002,'Sorry, error.');
end;
/

create or replace TYPE filter_row AS OBJECT (
  idtourn           number,
  login             VARCHAR2(30 BYTE),
  nametourn         VARCHAR2(10 BYTE),
  datastart         date,
  dataend           date,
  deltourn          number
);
/


CREATE TYPE filter_tab IS TABLE OF filter_row;
/


/*
create or replace FUNCTION get_tab(filter1 in VARCHAR2, filter2 in VARCHAR2) RETURN filter_tab PIPELINED AS
    TYPE strong_type IS REF CURSOR;
    dynamic_cursor strong_type;
      idtourn           number;
      login             VARCHAR2(30 BYTE);
      nametourn         VARCHAR2(10 BYTE);
      datastart         date;
      dataend           date;
      deltourn          number;
BEGIN
    OPEN dynamic_cursor FOR
        select tournament_id, organizer_login_fk, tournament_name,tournament_data_started,
         tournament_data_end, tournament_del from tournament 
         where lower(TOURNAMENT_NAME) like lower(filter1) and tournament_del = 0
         and lower(organizer_login_fk) like lower(filter2);
        LOOP
            FETCH dynamic_cursor INTO idtourn, login, nametourn, datastart, dataend, deltourn;
            EXIT WHEN dynamic_cursor%notfound;
            PIPE ROW(filter_row(idtourn, login, nametourn, datastart, dataend, deltourn));
        END LOOP;
    CLOSE dynamic_cursor;
  RETURN;
END;
/

create or replace FUNCTION getcountgoals(
	emailgoal IN Team.team_email%Type,
	datematch IN Date,
	emailother IN Team.team_email%Type,
    nume IN number
	) 
   RETURN INTEGER
   IS countgoals INTEGER;
   BEGIN 
   if (nume = 0) then
      SELECT COUNT(*) INTO countgoals
      FROM SCORE
      WHERE SCORE.team_goal = emailgoal
	  and SCORE.team2_email_fk = emailother 
      and SCORE.Game_DATA_FK = datematch and goal_del = 0
	GROUP BY SCORE.team_goal, SCORE.game_data_fk;
    end if;
    if (nume = 1) then
      SELECT COUNT(*) INTO countgoals
      FROM SCORE
      WHERE SCORE.team_goal = emailgoal
	  and SCORE.team1_email_fk = emailother
      and SCORE.Game_DATA_FK = datematch and goal_del = 0
	GROUP BY SCORE.team_goal, SCORE.game_data_fk;
    end if;
      RETURN(countgoals); 
    END;
/
	
create or replace FUNCTION getcountmainfilter(filters IN VARCHAR) 
   RETURN INTEGER
   IS counttourn INTEGER;
   BEGIN
	  SELECT COUNT(*) into counttourn
	  FROM TOURNAMENT 
	  WHERE lower(TOURNAMENT_NAME) Like lower(filters)
		and tournament_del = 0;
      RETURN(counttourn); 
    END;
/
	
CREATE FUNCTION getcounttourn(organizer_log IN ORGANIZER.ORGANIZER_LOGIN%Type) 
   RETURN INTEGER
   IS counttourn INTEGER;
   BEGIN
      SELECT COUNT(*) INTO counttourn
      FROM TOURNAMENT 
      WHERE Tournament.ORGANIZER_LOGIN_FK = organizer_log
	and tournament_del =0; 
      RETURN(counttourn); 
    END;
/
	
create or replace FUNCTION getcounttournfilter(organizer_log IN ORGANIZER.ORGANIZER_LOGIN%Type, filters IN VARCHAR) 
   RETURN INTEGER
   IS counttourn INTEGER;
   BEGIN
	  SELECT COUNT(*) into counttourn
	  FROM TOURNAMENT 
	  WHERE Tournament.ORGANIZER_LOGIN_FK = organizer_log and lower(TOURNAMENT_NAME) Like lower(filters)
		and tournament_del = 0;
      RETURN(counttourn); 
    END;
	/
	
create or replace PROCEDURE deletematch(team1 in team.team_email%type, 
		team2 in team.team_email%type, data_match in date)
IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION ISOLATION LEVEL SERIALIZable;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select game_data_fk, team1_email_fk, team2_email_fk from score 
		where game_data_fk = data_match and team1_email_fk = team1 and team2_email_fk = team2;
		LOOP
			FETCH dynamic_cursor into match_data2, team12, team22; 
			EXIT WHEN dynamic_cursor%notfound;
			UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE Game SET game_del = 1 where game_data = data_match and team1_email_fk = team1 and
			team2_email_fk = team2;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;
/

create or replace PROCEDURE deletetourn(org_name in ORGANIZER.ORGANIZER_LOGIN%type, ids in tournament.tournament_id%type)
IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	dynamic_cursor2 strong_type;
	match_data Game.game_data%type;
	team1 Team.team_email%type;
	team2 Team.team_email%type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION ISOLATION LEVEL SERIALIZable;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select game_data, team1_email_fk, team2_email_fk from game 
		where tournament_id_fk = ids and organizer_login_fk = org_name;
		LOOP
			FETCH dynamic_cursor into match_data, team1, team2; 
			EXIT WHEN dynamic_cursor%notfound;
            OPEN dynamic_cursor2 FOR 
                select game_data_fk, team1_email_fk, team2_email_fk from Score 
                where game_data_fk = match_data and team1_email_fk = team1 and
                    team2_email_fk = team2;
                LOOP
                    FETCH dynamic_cursor2 into match_data2, team12, team22; 
                    EXIT WHEN dynamic_cursor2%notfound;
                    UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
                END LOOP;
            CLOSE dynamic_cursor2;
			UPDATE game SET game_del = 1 where team1_email_fk = team1 and team2_email_fk = team2 and game_data = match_data;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE TOURNAMENT SET tournament_del = 1 where tournament_id = ids and organizer_login_fk = org_name;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;
/

create or replace PROCEDURE deleteorganizer(org_name in ORGANIZER.ORGANIZER_LOGIN%type)
IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	dynamic_cursor2 strong_type;
	dynamic_cursor3 strong_type;
	ids tournament.tournament_id%type;
	match_data Game.game_data%type;
	team1 Team.team_email%type;
	team2 Team.team_email%type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION READ WRITE;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select tournament_id from tournament 
		where organizer_login_fk = org_name;
		LOOP
			FETCH dynamic_cursor into ids; 
			EXIT WHEN dynamic_cursor%notfound;
            OPEN dynamic_cursor2 FOR
				select game_data, team1_email_fk, team2_email_fk from game 
				where tournament_id_fk = ids and organizer_login_fk = org_name;
				LOOP
					FETCH dynamic_cursor2 into match_data, team1, team2; 
					EXIT WHEN dynamic_cursor2%notfound;
					
					OPEN dynamic_cursor3 FOR 
						select game_data_fk, team1_email_fk, team2_email_fk from Score 
						where game_data_fk = match_data and team1_email_fk = team1 and
							team2_email_fk = team2;
						LOOP
							FETCH dynamic_cursor3 into match_data2, team12, team22; 
							EXIT WHEN dynamic_cursor3%notfound;
							UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
						END LOOP;
					CLOSE dynamic_cursor3;
					UPDATE game SET game_del = 1 where team1_email_fk = team1 and team2_email_fk = team2 and game_data = match_data;
				END LOOP;
			CLOSE dynamic_cursor2;
			UPDATE tournament SET tournament_del = 1 where tournament_id = ids and organizer_login_fk = org_name;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE organizer SET organizer_del = 1 where organizer_login = org_name;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;
/

create or replace PROCEDURE SearchElements(
    filters         in  VARCHAR2,
    dynamic_cursor   OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN dynamic_cursor FOR 
      select * from tournament where lower(TOURNAMENT_NAME) like lower(filters) 
	and tournament_del = 0;
END;
/

create or replace PROCEDURE Selecttourninfo(
    org_name         in  ORGANIZER.ORGANIZER_LOGIN%type,
	ids         in  tournament.tournament_id%type,
    dynamic_cursor   OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN dynamic_cursor FOR 
      select game_data, team1_email_fk, team2_email_fk 
      from Game where organizer_login_fk = org_name and tournament_id_fk = ids and GAME_DEL = 0;
END;
/

create or replace PROCEDURE SelectorganizerData(
    dynamic_cursor   OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN dynamic_cursor FOR 
		select organizer_login, organizer_email 
		from organizer where organizer_del = 0 and organizer_admin = 0;
END;
/

create or replace PROCEDURE Selectorganizerinfo(
    org_name         in  ORGANIZER.ORGANIZER_LOGIN%type,
    dynamic_cursor   OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN dynamic_cursor FOR 
      select tournament_id 
      from Tournament where organizer_login_fk = org_name and tournament_DEL = 0;
END;
/

create or replace PROCEDURE SelecttournamentData(
    org_name         in  ORGANIZER.ORGANIZER_LOGIN%type,
    dynamic_cursor   OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN dynamic_cursor FOR 
      select tournament_id, organizer_login_fk, tournament_name,tournament_data_started, tournament_data_end 
      from tournament where organizer_login_fk = org_name and tournament_del = 0;
END;
/

create or replace PROCEDURE 
        getteamname(email IN TEAM.TEAM_EMAIL%type, t_name OUT TEAM.TEAM_NAME%type) 
    AS
        BEGIN
            select team_for_admin.tm_name INTO t_name
            from team_for_admin
            where team_for_admin.tm_email = email;
        END;
	/
	*/	
/*head 1 */
create or replace PACKAGE countnumber AS 
    FUNCTION getcountgoals(emailgoal in Team.team_email%Type,
            datematch in Date, emailother in Team.team_email%Type,
            nume in number) RETURN INTEGER;
    FUNCTION getcountmainfilter(filters in VARCHAR) RETURN INTEGER;  
    FUNCTION getcounttourn(organizer_log in ORGANIZER.ORGANIZER_LOGIN%Type)
            RETURN INTEGER;
    FUNCTION getcounttournfilter(organizer_log in ORGANIZER.ORGANIZER_LOGIN%Type, 
            filters in VARCHAR) RETURN INTEGER;
END countnumber;
/


/*head 2 */
create or replace PACKAGE Filters AS 
    FUNCTION get_tab(filter1 in VARCHAR2, filter2 in VARCHAR2) RETURN filter_tab pipelined;
    PROCEDURE SearchElements(filters in VARCHAR2, dynamic_cursor out SYS_REFCURSOR); 
END Filters;
/


/*head 3 */
create or replace PACKAGE SelectData AS       
    PROCEDURE getteamname(email in TEAM.TEAM_EMAIL%type,
            t_name out TEAM.TEAM_NAME%type);   
    PROCEDURE SelectorganizerData(dynamic_cursor out SYS_REFCURSOR);
    PROCEDURE Selectorganizerinfo(org_name in ORGANIZER.ORGANIZER_LOGIN%type, 
            dynamic_cursor out SYS_REFCURSOR);
    PROCEDURE SelecttournamentData(org_name in ORGANIZER.ORGANIZER_LOGIN%type,
            dynamic_cursor out SYS_REFCURSOR);
    PROCEDURE Selecttourninfo(org_name in ORGANIZER.ORGANIZER_LOGIN%type,
            ids in tournament.tournament_id%type,dynamic_cursor out SYS_REFCURSOR);
END SelectData;
/


/*head 4 */
create or replace PACKAGE Changespro AS 
    PROCEDURE deletetourn(org_name in ORGANIZER.ORGANIZER_LOGIN%type, ids in tournament.tournament_id%type);
    PROCEDURE deleteorganizer(org_name in ORGANIZER.ORGANIZER_LOGIN%type);    
	PROCEDURE deletematch(team1 in team.team_email%type, 
			team2 in team.team_email%type, data_match in date); 	
END Changespro;
/


/*body 1 */
create or replace PACKAGE BODY countnumber AS
FUNCTION getcountgoals
    (emailgoal in Team.team_email%Type, datematch in Date,
	emailother in Team.team_email%Type, nume in number) RETURN INTEGER
    IS countgoals INTEGER;
BEGIN
    if (nume = 0) then
        SELECT COUNT(*) INTO countgoals
        FROM SCORE
        WHERE SCORE.team_goal = emailgoal
        and SCORE.team2_email_fk = emailother 
        and SCORE.Game_DATA_FK = datematch and goal_del = 0
        GROUP BY SCORE.team_goal, SCORE.game_data_fk;
    end if;
    if (nume = 1) then
        SELECT COUNT(*) INTO countgoals
        FROM SCORE
        WHERE SCORE.team_goal = emailgoal
        and SCORE.team1_email_fk = emailother
        and SCORE.Game_DATA_FK = datematch and goal_del = 0
        GROUP BY SCORE.team_goal, SCORE.game_data_fk;
    end if;
    RETURN(countgoals); 
END;

FUNCTION getcountmainfilter(filters in VARCHAR) 
    RETURN INTEGER
    IS counttourn INTEGER;
BEGIN
    SELECT COUNT(*) into counttourn
    FROM TOURNAMENT 
    WHERE lower(TOURNAMENT_NAME) Like lower(filters)
    and tournament_del = 0;
    RETURN(counttourn); 
END;

FUNCTION getcounttourn(organizer_log in ORGANIZER.ORGANIZER_LOGIN%Type) 
    RETURN INTEGER
    IS counttourn INTEGER;
BEGIN 
    SELECT COUNT(*) INTO counttourn
    FROM TOURNAMENT 
    WHERE Tournament.ORGANIZER_LOGIN_FK = organizer_log
	and tournament_del =0; 
    RETURN(counttourn); 
END;

FUNCTION getcounttournfilter(organizer_log in ORGANIZER.ORGANIZER_LOGIN%Type, filters in VARCHAR) 
    RETURN INTEGER
    IS counttourn INTEGER;
BEGIN
    SELECT COUNT(*) into counttourn
    FROM TOURNAMENT 
    WHERE Tournament.ORGANIZER_LOGIN_FK = organizer_log and lower(TOURNAMENT_NAME) Like lower(filters)
    and tournament_del = 0;
    RETURN(counttourn); 
END;

END countnumber;
/


/*body 2 */
create or replace PACKAGE BODY filters AS
FUNCTION get_tab(filter1 in VARCHAR2, filter2 in VARCHAR2) RETURN filter_tab PIPELINED AS
    TYPE strong_type IS REF CURSOR;
    dynamic_cursor strong_type;
      idtourn           number;
      login             VARCHAR2(30 BYTE);
      nametourn         VARCHAR2(10 BYTE);
      datastart         date;
      dataend           date;
      deltourn          number;
BEGIN
    OPEN dynamic_cursor FOR
        select tournament_id, organizer_login_fk, tournament_name,tournament_data_started,
         tournament_data_end, tournament_del from tournament 
         where lower(TOURNAMENT_NAME) like lower(filter1) and tournament_del = 0
         and lower(organizer_login_fk) like lower(filter2);
        LOOP
            FETCH dynamic_cursor INTO idtourn, login, nametourn, datastart, dataend, deltourn;
            EXIT WHEN dynamic_cursor%notfound;
            PIPE ROW(filter_row(idtourn, login, nametourn, datastart, dataend, deltourn));
        END LOOP;
    CLOSE dynamic_cursor;
  RETURN;
END;

PROCEDURE SearchElements(
    filters    in      VARCHAR2,
    dynamic_cursor out  SYS_REFCURSOR)
    IS
BEGIN
    OPEN dynamic_cursor FOR 
        select * from tournament where lower(TOURNAMENT_NAME) like lower(filters) 
	and tournament_del = 0;
END;

END filters;
/


/*body 3 */
create or replace PACKAGE BODY selectdata AS
PROCEDURE getteamname (email in TEAM.TEAM_EMAIL%type, t_name out TEAM.TEAM_NAME%type) 
    AS
BEGIN
    select team_for_admin.tm_name INTO t_name
    from team_for_admin
    where team_for_admin.tm_email = email;
END;

PROCEDURE SelectorganizerData(dynamic_cursor out  SYS_REFCURSOR)
    IS
BEGIN
    OPEN dynamic_cursor FOR 
        select organizer_login, organizer_email 
        from organizer where organizer_del = 0 and organizer_admin = 0;
END;

PROCEDURE Selectorganizerinfo(
    org_name    in     ORGANIZER.ORGANIZER_LOGIN%type,
    dynamic_cursor out  SYS_REFCURSOR)
    IS
BEGIN
    OPEN dynamic_cursor FOR 
        select tournament_id 
        from Tournament where organizer_login_fk = org_name and tournament_DEL = 0;
END;

PROCEDURE SelecttournamentData(
    org_name    in     ORGANIZER.ORGANIZER_LOGIN%type,
    dynamic_cursor out  SYS_REFCURSOR)
    IS
BEGIN
    OPEN dynamic_cursor FOR 
        select tournament_id, organizer_login_fk, tournament_name,tournament_data_started, tournament_data_end 
        from tournament where organizer_login_fk = org_name and tournament_del = 0;
END;

PROCEDURE Selecttourninfo(
    org_name   in      ORGANIZER.ORGANIZER_LOGIN%type,
	ids      in   tournament.tournament_id%type,
    dynamic_cursor Out  SYS_REFCURSOR)
    IS
BEGIN
    OPEN dynamic_cursor FOR 
        select game_data, team1_email_fk, team2_email_fk 
        from Game where organizer_login_fk = org_name and tournament_id_fk = ids and GAME_DEL = 0;
END;
END selectdata;
/


/* body 4 */

create or replace PACKAGE BODY Changespro AS
PROCEDURE deletetourn(org_name in ORGANIZER.ORGANIZER_LOGIN%type, ids in tournament.tournament_id%type)
	IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	dynamic_cursor2 strong_type;
	match_data Game.game_data%type;
	team1 Team.team_email%type;
	team2 Team.team_email%type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION ISOLATION LEVEL SERIALIZable;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select game_data, team1_email_fk, team2_email_fk from game 
		where tournament_id_fk = ids and organizer_login_fk = org_name;
		LOOP
			FETCH dynamic_cursor into match_data, team1, team2; 
			EXIT WHEN dynamic_cursor%notfound;
            OPEN dynamic_cursor2 FOR 
                select game_data_fk, team1_email_fk, team2_email_fk from Score 
                where game_data_fk = match_data and team1_email_fk = team1 and
                    team2_email_fk = team2;
                LOOP
                    FETCH dynamic_cursor2 into match_data2, team12, team22; 
                    EXIT WHEN dynamic_cursor2%notfound;
                    UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
                END LOOP;
            CLOSE dynamic_cursor2;
			UPDATE game SET game_del = 1 where team1_email_fk = team1 and team2_email_fk = team2 and game_data = match_data;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE TOURNAMENT SET tournament_del = 1 where tournament_id = ids and organizer_login_fk = org_name;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;

PROCEDURE deleteorganizer(org_name in ORGANIZER.ORGANIZER_LOGIN%type)
	IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	dynamic_cursor2 strong_type;
	dynamic_cursor3 strong_type;
	ids tournament.tournament_id%type;
	match_data Game.game_data%type;
	team1 Team.team_email%type;
	team2 Team.team_email%type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION READ WRITE;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select tournament_id from tournament 
		where organizer_login_fk = org_name;
		LOOP
			FETCH dynamic_cursor into ids; 
			EXIT WHEN dynamic_cursor%notfound;
            OPEN dynamic_cursor2 FOR
				select game_data, team1_email_fk, team2_email_fk from game 
				where tournament_id_fk = ids and organizer_login_fk = org_name;
				LOOP
					FETCH dynamic_cursor2 into match_data, team1, team2; 
					EXIT WHEN dynamic_cursor2%notfound;
					
					OPEN dynamic_cursor3 FOR 
						select game_data_fk, team1_email_fk, team2_email_fk from Score 
						where game_data_fk = match_data and team1_email_fk = team1 and
							team2_email_fk = team2;
						LOOP
							FETCH dynamic_cursor3 into match_data2, team12, team22; 
							EXIT WHEN dynamic_cursor3%notfound;
							UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
						END LOOP;
					CLOSE dynamic_cursor3;
					UPDATE game SET game_del = 1 where team1_email_fk = team1 and team2_email_fk = team2 and game_data = match_data;
				END LOOP;
			CLOSE dynamic_cursor2;
			UPDATE tournament SET tournament_del = 1 where tournament_id = ids and organizer_login_fk = org_name;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE organizer SET organizer_del = 1 where organizer_login = org_name;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;

PROCEDURE deletematch(team1 in team.team_email%type, 
		team2 in team.team_email%type, data_match in date)
	IS
	TYPE strong_type IS REF CURSOR;
	dynamic_cursor strong_type;
	match_data2 Game.game_data%type;
	team12 Team.team_email%type;
	team22 Team.team_email%type;
BEGIN
	COMMIT;
    SET TRANSACTION ISOLATION LEVEL SERIALIZable;
	SAVEPOINT mainsavepoint;
	OPEN dynamic_cursor FOR
		select game_data_fk, team1_email_fk, team2_email_fk from score 
		where game_data_fk = data_match and team1_email_fk = team1 and team2_email_fk = team2;
		LOOP
			FETCH dynamic_cursor into match_data2, team12, team22; 
			EXIT WHEN dynamic_cursor%notfound;
			UPDATE Score SET goal_del = 1 where team1_email_fk = team12 and team2_email_fk = team22 and game_data_fk = match_data2;
		END LOOP;
	CLOSE dynamic_cursor;
	UPDATE Game SET game_del = 1 where game_data = data_match and team1_email_fk = team1 and
			team2_email_fk = team2;
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK to mainsavepoint;
		raise_application_error (-20002,'Sorry, error.');
END;

END Changespro;
/

Commit;
/




	  
	  
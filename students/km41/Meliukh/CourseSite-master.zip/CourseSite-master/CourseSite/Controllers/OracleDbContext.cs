using System.Collections.Generic;
using System;
using System.Data.Entity;
using System.Linq;


namespace CourseSite.Controllers
{

   
    public class OracleDbContext : DbContext
    {
        public OracleDbContext()
            : base("name=OracleDbContext")
        {
        }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Student> Students { get; set; }

        public virtual DbSet<Teacher> Teachers { get; set; }

        public virtual DbSet<Work> Works { get; set; }

        public virtual DbSet<Checked> Checkeds { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("VIKA");
        }

    }



    public class User
    {
        public string Id { get; set; }

        public string FName { get; set; }

        public string LName { get; set; }
        
        public string UserEmail { get; set; }
       
    }

    public class Student: User
    {
        public string GroupName { get; set; }

        public List<Work> Works { get; set; }
    }

    public class Teacher: User
    {
        public string CathedraName { get; set; }
    }

    public class Work
    {
        public string Id { get; set; }

        public DateTime Date_upload { get; set; }

        public Byte[] file { get; set; }

        public decimal AvaregeRating { get; set; }

        public List<Checked> CheckedWorks { get; set; }
    }

    public class Checked
    {
        public DateTime Date_checked { get; set; }

        public int Rating { get; set; }

    }
}
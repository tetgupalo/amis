<?php
if(isset($_COOKIE['login'])){
	if(isset($_COOKIE['admin'])){
		header("Location: adminpage.php"); exit;
	}
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>
	
	<link rel="stylesheet" href="css/style.css">
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	<script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="main.php">Home
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="main.php#ex2">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Sign up</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#">Sign in
				<span class="sr-only">(current)</span>
			  </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	<div class="login-page">
		<div class="form">
			<form class="login-form" action="logphp.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<input type="text" name="organizer_login" pattern="^[A-z0-9_.]{8,30}$" title="This value is not valid" class="form-control" placeholder="username" required/>
				</div>
				<div class="form-group">
					<input type="password" name="organizer_password" pattern=".{8,30}$" title="This value is not valid" class="form-control" placeholder="password" required/>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >sign in<span class="glyphicon glyphicon-send"></span></button>
				</div>
				<p class="message">Not registered? <a href="register.php">Create an account</a></p>
				</fieldset>
			</form>			
		</div>	
	</div> 	
	
	</body>
</html>
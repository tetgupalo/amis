from django.conf.urls import url
from .views import AdminMenu, EditMenu, DeleteMenu

urlpatterns = [

	url(r'^$', AdminMenu.as_view(), name='admin_menu'),

	url(r'^edit/(?P<pk>\d+)/$', EditMenu.as_view(), name='edit'),

	url(r'^delete/(?P<pk>\d+)/$', DeleteMenu.as_view(), name='delete'),

]

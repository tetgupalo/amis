from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.urls import reverse
from django.utils import timezone
from django.db import connection
from django.db import transaction

from .models import Cleaning_company, Cleaner, Order


@method_decorator(login_required, name='dispatch')
class OrderDetails(View):

    def get(self, request, pk):
        # order = Order.objects.get(pk=pk)

        cursor = connection.cursor()
        cursor.execute('SELECT "USERNAME",\
            "CLEANER_ID", \
            "CLEANER_NAME", \
            "CREATE_TIME", \
            "CLEANING_COMPANY_ID", \
            "CLEANING_COMPANY_NAME" \
            FROM "ORDER_VIEW" \
            WHERE "ORDER_ID" = {order_id}'.format(order_id=pk))

        USERNAME, CLEANER_ID, CLEANER_NAME, CREATE_TIME, CLEANING_COMPANY_ID, CLEANING_COMPANY_NAME = cursor.fetchone()

        context = {
            "CREATE_TIME": CREATE_TIME,
            "USERNAME": USERNAME,
            "CLEANER_ID": CLEANER_ID,
            "CLEANER_NAME": CLEANER_NAME,
            "CLEANING_COMPANY_ID": CLEANING_COMPANY_ID,
            "CLEANING_COMPANY_NAME": CLEANING_COMPANY_NAME
        }

        return render(request, 'cleaning/order-details.html', context)


@method_decorator(login_required, name='dispatch')
class AllCleaning(View):

    def get(self, request):
        FIELDS = 'ID, NAME, DESCRIPTION,CITY, COMPANY_LOGO, PRICE_PER_SQUARE_METR, SQUARE_METERS_PER_HOUR'
        # cleaning_companies = Cleaning_company.objects.all()
        cleaning_companies = Cleaning_company.objects.raw('SELECT {FIELDS} FROM CLEANING_CLEANING_COMPANY'.format(FIELDS=FIELDS))

        context = {'cleaning_companies': cleaning_companies}

        return render(request, 'cleaning/cleaning-companies.html', context)


@method_decorator(login_required, name='dispatch')
class CleaningDetails(View):

    def get(self, request, pk):
        now = timezone.now()
        cleaning_company = Cleaning_company.objects.get(pk=pk)
        company_personal = Cleaner.objects.filter(cleaning_company_id=pk)
        for cleaner in company_personal:
            if cleaner.busy_to and cleaner.busy_to < now:
                cleaner.busy_from = None
                cleaner.busy_to = None
                cleaner.save()

        context = {'cleaning_company': cleaning_company,
                   'company_personal': company_personal}

        return render(request, 'cleaning/cleaning-company-details.html', context)


@method_decorator(login_required, name='dispatch')
class CleanerDetails(View):

    def get(self, request, pk):
        now = timezone.now()
        cleaner = Cleaner.objects.get(pk=pk)

        if cleaner.busy_to and cleaner.busy_to < now:
            cleaner.busy_from = None
            cleaner.busy_to = None
            cleaner.save()

        cleaner_order = Order.objects.filter(cleaning_person_id=pk)
        context = {'cleaner': cleaner, 'cleaner_order': cleaner_order}

        return render(request, 'cleaning/cleaner-details.html', context)

    def post(self, request, pk):
        square_meters = int(request.POST.get('square_meters'))
        get_time = request.POST.get('date')
        hour = get_time.split(':')[0]
        minutes = get_time.split(':')[1]
        id_out = ""


        cleaner = Cleaner.objects.get(pk=pk)

        import datetime
        from datetime import date, time
        from django.utils import timezone

        date = date.today()

        _time = time(int(hour), int(minutes),
                     tzinfo=timezone.get_current_timezone())
        aware_datetime = datetime.datetime.combine(date, _time)
        cleaner.busy_from = aware_datetime

        working_time = round(
            (square_meters / int(cleaner.cleaning_company.square_meters_per_hour)) + .5)

        cleaner.money_earned += working_time * cleaner.cleaning_company.price_per_square_metr

        while True:
            try:
                cleaner.busy_to = time(
                    int(hour) + working_time, int(minutes), tzinfo=timezone.get_current_timezone())
            except Exception:
                date = date.today() + datetime.timedelta(1)
                working_time -= 24
            if working_time + int(hour) < 24:
                _time = time(int(hour) + working_time, int(minutes),
                             tzinfo=timezone.get_current_timezone())
                aware_datetime = datetime.datetime.combine(date, _time)
                cleaner.busy_to = aware_datetime
                break

        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
            

            order_id_str = cursor.callproc('ORDER_PACKAGE.CREATE_ORDER_PROCEDURE', 
                [request.user.id, pk, square_meters, id_out])
            # order = Order.objects.create( 
            #     user_id=request.user.id, cleaning_person_id=pk, square_meters=square_meters)
            
            cleaner.save()

        order_id = int(order_id_str[-1])

        return redirect(reverse('cleaning:order_details', args=(order_id,)))


@method_decorator(login_required, name='dispatch')
class UserOrderDetails(View):

    def get(self, request, pk):
        orders = Order.objects.filter(user_id=pk)

        context = {'orders': orders}

        return render(request, 'cleaning/user-orders-details.html', context)

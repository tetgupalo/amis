﻿namespace Coursework1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvcomps = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.cbcompname = new System.Windows.Forms.CheckBox();
            this.combocomp = new System.Windows.Forms.ComboBox();
            this.tbcomp = new System.Windows.Forms.TextBox();
            this.tbvideo = new System.Windows.Forms.TextBox();
            this.combovideo = new System.Windows.Forms.ComboBox();
            this.cbvidname = new System.Windows.Forms.CheckBox();
            this.tbvmem = new System.Windows.Forms.TextBox();
            this.combovmem = new System.Windows.Forms.ComboBox();
            this.cbvidmem = new System.Windows.Forms.CheckBox();
            this.tbhdd = new System.Windows.Forms.TextBox();
            this.combohdd = new System.Windows.Forms.ComboBox();
            this.cbhdd = new System.Windows.Forms.CheckBox();
            this.tbstore = new System.Windows.Forms.TextBox();
            this.combostore = new System.Windows.Forms.ComboBox();
            this.cbstorename = new System.Windows.Forms.CheckBox();
            this.tbadres = new System.Windows.Forms.TextBox();
            this.comboadres = new System.Windows.Forms.ComboBox();
            this.cbstoreaddress = new System.Windows.Forms.CheckBox();
            this.tbprice1 = new System.Windows.Forms.TextBox();
            this.comboprice = new System.Windows.Forms.ComboBox();
            this.cbprice = new System.Windows.Forms.CheckBox();
            this.tbmem = new System.Windows.Forms.TextBox();
            this.combomem = new System.Windows.Forms.ComboBox();
            this.cbmemory = new System.Windows.Forms.CheckBox();
            this.tbprice2 = new System.Windows.Forms.TextBox();
            this.srchbutton = new System.Windows.Forms.Button();
            this.dgvstores = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcomps)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstores)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvcomps
            // 
            this.dgvcomps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcomps.Location = new System.Drawing.Point(12, 88);
            this.dgvcomps.Name = "dgvcomps";
            this.dgvcomps.Size = new System.Drawing.Size(636, 263);
            this.dgvcomps.TabIndex = 3;
            this.dgvcomps.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvcomps_RowEnter);
            this.dgvcomps.RowLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvcomps_RowLeave);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 357);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbcompname
            // 
            this.cbcompname.AutoSize = true;
            this.cbcompname.Location = new System.Drawing.Point(12, 12);
            this.cbcompname.Name = "cbcompname";
            this.cbcompname.Size = new System.Drawing.Size(100, 17);
            this.cbcompname.TabIndex = 5;
            this.cbcompname.Text = "Computer name";
            this.cbcompname.UseVisualStyleBackColor = true;
            this.cbcompname.CheckedChanged += new System.EventHandler(this.cbcompname_CheckedChanged);
            // 
            // combocomp
            // 
            this.combocomp.FormattingEnabled = true;
            this.combocomp.Location = new System.Drawing.Point(12, 35);
            this.combocomp.Name = "combocomp";
            this.combocomp.Size = new System.Drawing.Size(121, 21);
            this.combocomp.TabIndex = 6;
            this.combocomp.Visible = false;
            // 
            // tbcomp
            // 
            this.tbcomp.Location = new System.Drawing.Point(12, 62);
            this.tbcomp.Name = "tbcomp";
            this.tbcomp.Size = new System.Drawing.Size(121, 20);
            this.tbcomp.TabIndex = 7;
            this.tbcomp.Visible = false;
            // 
            // tbvideo
            // 
            this.tbvideo.Location = new System.Drawing.Point(139, 62);
            this.tbvideo.Name = "tbvideo";
            this.tbvideo.Size = new System.Drawing.Size(121, 20);
            this.tbvideo.TabIndex = 10;
            this.tbvideo.Visible = false;
            // 
            // combovideo
            // 
            this.combovideo.FormattingEnabled = true;
            this.combovideo.Location = new System.Drawing.Point(139, 35);
            this.combovideo.Name = "combovideo";
            this.combovideo.Size = new System.Drawing.Size(121, 21);
            this.combovideo.TabIndex = 9;
            this.combovideo.Visible = false;
            // 
            // cbvidname
            // 
            this.cbvidname.AutoSize = true;
            this.cbvidname.Location = new System.Drawing.Point(139, 12);
            this.cbvidname.Name = "cbvidname";
            this.cbvidname.Size = new System.Drawing.Size(103, 17);
            this.cbvidname.TabIndex = 8;
            this.cbvidname.Text = "Videocard name";
            this.cbvidname.UseVisualStyleBackColor = true;
            this.cbvidname.CheckedChanged += new System.EventHandler(this.cbvidname_CheckedChanged);
            // 
            // tbvmem
            // 
            this.tbvmem.Location = new System.Drawing.Point(266, 62);
            this.tbvmem.Name = "tbvmem";
            this.tbvmem.Size = new System.Drawing.Size(121, 20);
            this.tbvmem.TabIndex = 13;
            this.tbvmem.Visible = false;
            // 
            // combovmem
            // 
            this.combovmem.FormattingEnabled = true;
            this.combovmem.Location = new System.Drawing.Point(266, 35);
            this.combovmem.Name = "combovmem";
            this.combovmem.Size = new System.Drawing.Size(121, 21);
            this.combovmem.TabIndex = 12;
            this.combovmem.Visible = false;
            // 
            // cbvidmem
            // 
            this.cbvidmem.AutoSize = true;
            this.cbvidmem.Location = new System.Drawing.Point(266, 12);
            this.cbvidmem.Name = "cbvidmem";
            this.cbvidmem.Size = new System.Drawing.Size(123, 17);
            this.cbvidmem.TabIndex = 11;
            this.cbvidmem.Text = "Size of videomemory";
            this.cbvidmem.UseVisualStyleBackColor = true;
            this.cbvidmem.CheckedChanged += new System.EventHandler(this.cbvidmem_CheckedChanged);
            // 
            // tbhdd
            // 
            this.tbhdd.Location = new System.Drawing.Point(527, 62);
            this.tbhdd.Name = "tbhdd";
            this.tbhdd.Size = new System.Drawing.Size(121, 20);
            this.tbhdd.TabIndex = 16;
            this.tbhdd.Visible = false;
            // 
            // combohdd
            // 
            this.combohdd.FormattingEnabled = true;
            this.combohdd.Location = new System.Drawing.Point(527, 35);
            this.combohdd.Name = "combohdd";
            this.combohdd.Size = new System.Drawing.Size(121, 21);
            this.combohdd.TabIndex = 15;
            this.combohdd.Visible = false;
            // 
            // cbhdd
            // 
            this.cbhdd.AutoSize = true;
            this.cbhdd.Location = new System.Drawing.Point(527, 12);
            this.cbhdd.Name = "cbhdd";
            this.cbhdd.Size = new System.Drawing.Size(85, 17);
            this.cbhdd.TabIndex = 14;
            this.cbhdd.Text = "Size of HDD";
            this.cbhdd.UseVisualStyleBackColor = true;
            this.cbhdd.CheckedChanged += new System.EventHandler(this.cbhdd_CheckedChanged);
            // 
            // tbstore
            // 
            this.tbstore.Location = new System.Drawing.Point(654, 62);
            this.tbstore.Name = "tbstore";
            this.tbstore.Size = new System.Drawing.Size(121, 20);
            this.tbstore.TabIndex = 19;
            this.tbstore.Visible = false;
            // 
            // combostore
            // 
            this.combostore.FormattingEnabled = true;
            this.combostore.Location = new System.Drawing.Point(654, 35);
            this.combostore.Name = "combostore";
            this.combostore.Size = new System.Drawing.Size(121, 21);
            this.combostore.TabIndex = 18;
            this.combostore.Visible = false;
            // 
            // cbstorename
            // 
            this.cbstorename.AutoSize = true;
            this.cbstorename.Location = new System.Drawing.Point(654, 12);
            this.cbstorename.Name = "cbstorename";
            this.cbstorename.Size = new System.Drawing.Size(80, 17);
            this.cbstorename.TabIndex = 17;
            this.cbstorename.Text = "Store name";
            this.cbstorename.UseVisualStyleBackColor = true;
            this.cbstorename.CheckedChanged += new System.EventHandler(this.cbstorename_CheckedChanged);
            // 
            // tbadres
            // 
            this.tbadres.Location = new System.Drawing.Point(781, 62);
            this.tbadres.Name = "tbadres";
            this.tbadres.Size = new System.Drawing.Size(121, 20);
            this.tbadres.TabIndex = 22;
            this.tbadres.Visible = false;
            // 
            // comboadres
            // 
            this.comboadres.FormattingEnabled = true;
            this.comboadres.Location = new System.Drawing.Point(781, 35);
            this.comboadres.Name = "comboadres";
            this.comboadres.Size = new System.Drawing.Size(121, 21);
            this.comboadres.TabIndex = 21;
            this.comboadres.Visible = false;
            // 
            // cbstoreaddress
            // 
            this.cbstoreaddress.AutoSize = true;
            this.cbstoreaddress.Location = new System.Drawing.Point(781, 12);
            this.cbstoreaddress.Name = "cbstoreaddress";
            this.cbstoreaddress.Size = new System.Drawing.Size(91, 17);
            this.cbstoreaddress.TabIndex = 20;
            this.cbstoreaddress.Text = "Store address";
            this.cbstoreaddress.UseVisualStyleBackColor = true;
            this.cbstoreaddress.CheckedChanged += new System.EventHandler(this.cbstoreaddress_CheckedChanged);
            // 
            // tbprice1
            // 
            this.tbprice1.Location = new System.Drawing.Point(908, 62);
            this.tbprice1.Name = "tbprice1";
            this.tbprice1.Size = new System.Drawing.Size(60, 20);
            this.tbprice1.TabIndex = 25;
            this.tbprice1.Visible = false;
            // 
            // comboprice
            // 
            this.comboprice.FormattingEnabled = true;
            this.comboprice.Location = new System.Drawing.Point(908, 35);
            this.comboprice.Name = "comboprice";
            this.comboprice.Size = new System.Drawing.Size(121, 21);
            this.comboprice.TabIndex = 24;
            this.comboprice.Visible = false;
            this.comboprice.SelectedIndexChanged += new System.EventHandler(this.comboprice_SelectedIndexChanged);
            // 
            // cbprice
            // 
            this.cbprice.AutoSize = true;
            this.cbprice.Location = new System.Drawing.Point(908, 12);
            this.cbprice.Name = "cbprice";
            this.cbprice.Size = new System.Drawing.Size(50, 17);
            this.cbprice.TabIndex = 23;
            this.cbprice.Text = "Price";
            this.cbprice.UseVisualStyleBackColor = true;
            this.cbprice.CheckedChanged += new System.EventHandler(this.cbprice_CheckedChanged);
            // 
            // tbmem
            // 
            this.tbmem.Location = new System.Drawing.Point(393, 62);
            this.tbmem.Name = "tbmem";
            this.tbmem.Size = new System.Drawing.Size(121, 20);
            this.tbmem.TabIndex = 28;
            this.tbmem.Visible = false;
            // 
            // combomem
            // 
            this.combomem.FormattingEnabled = true;
            this.combomem.Location = new System.Drawing.Point(393, 35);
            this.combomem.Name = "combomem";
            this.combomem.Size = new System.Drawing.Size(121, 21);
            this.combomem.TabIndex = 27;
            this.combomem.Visible = false;
            // 
            // cbmemory
            // 
            this.cbmemory.AutoSize = true;
            this.cbmemory.Location = new System.Drawing.Point(393, 12);
            this.cbmemory.Name = "cbmemory";
            this.cbmemory.Size = new System.Drawing.Size(84, 17);
            this.cbmemory.TabIndex = 26;
            this.cbmemory.Text = "Memory size";
            this.cbmemory.UseVisualStyleBackColor = true;
            this.cbmemory.CheckedChanged += new System.EventHandler(this.cbmemory_CheckedChanged);
            // 
            // tbprice2
            // 
            this.tbprice2.Location = new System.Drawing.Point(974, 62);
            this.tbprice2.Name = "tbprice2";
            this.tbprice2.Size = new System.Drawing.Size(60, 20);
            this.tbprice2.TabIndex = 29;
            this.tbprice2.Visible = false;
            // 
            // srchbutton
            // 
            this.srchbutton.Location = new System.Drawing.Point(959, 357);
            this.srchbutton.Name = "srchbutton";
            this.srchbutton.Size = new System.Drawing.Size(75, 23);
            this.srchbutton.TabIndex = 30;
            this.srchbutton.Text = "Search";
            this.srchbutton.UseVisualStyleBackColor = true;
            this.srchbutton.Click += new System.EventHandler(this.srchbutton_Click);
            // 
            // dgvstores
            // 
            this.dgvstores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvstores.Location = new System.Drawing.Point(654, 88);
            this.dgvstores.Name = "dgvstores";
            this.dgvstores.Size = new System.Drawing.Size(375, 263);
            this.dgvstores.TabIndex = 31;
            this.dgvstores.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 392);
            this.Controls.Add(this.dgvstores);
            this.Controls.Add(this.srchbutton);
            this.Controls.Add(this.tbprice2);
            this.Controls.Add(this.tbmem);
            this.Controls.Add(this.combomem);
            this.Controls.Add(this.cbmemory);
            this.Controls.Add(this.tbprice1);
            this.Controls.Add(this.comboprice);
            this.Controls.Add(this.cbprice);
            this.Controls.Add(this.tbadres);
            this.Controls.Add(this.comboadres);
            this.Controls.Add(this.cbstoreaddress);
            this.Controls.Add(this.tbstore);
            this.Controls.Add(this.combostore);
            this.Controls.Add(this.cbstorename);
            this.Controls.Add(this.tbhdd);
            this.Controls.Add(this.combohdd);
            this.Controls.Add(this.cbhdd);
            this.Controls.Add(this.tbvmem);
            this.Controls.Add(this.combovmem);
            this.Controls.Add(this.cbvidmem);
            this.Controls.Add(this.tbvideo);
            this.Controls.Add(this.combovideo);
            this.Controls.Add(this.cbvidname);
            this.Controls.Add(this.tbcomp);
            this.Controls.Add(this.combocomp);
            this.Controls.Add(this.cbcompname);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvcomps);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvcomps)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvcomps;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox cbcompname;
        private System.Windows.Forms.ComboBox combocomp;
        private System.Windows.Forms.TextBox tbcomp;
        private System.Windows.Forms.TextBox tbvideo;
        private System.Windows.Forms.ComboBox combovideo;
        private System.Windows.Forms.CheckBox cbvidname;
        private System.Windows.Forms.TextBox tbvmem;
        private System.Windows.Forms.ComboBox combovmem;
        private System.Windows.Forms.CheckBox cbvidmem;
        private System.Windows.Forms.TextBox tbhdd;
        private System.Windows.Forms.ComboBox combohdd;
        private System.Windows.Forms.CheckBox cbhdd;
        private System.Windows.Forms.TextBox tbstore;
        private System.Windows.Forms.ComboBox combostore;
        private System.Windows.Forms.CheckBox cbstorename;
        private System.Windows.Forms.TextBox tbadres;
        private System.Windows.Forms.ComboBox comboadres;
        private System.Windows.Forms.CheckBox cbstoreaddress;
        private System.Windows.Forms.TextBox tbprice1;
        private System.Windows.Forms.ComboBox comboprice;
        private System.Windows.Forms.CheckBox cbprice;
        private System.Windows.Forms.TextBox tbmem;
        private System.Windows.Forms.ComboBox combomem;
        private System.Windows.Forms.CheckBox cbmemory;
        private System.Windows.Forms.TextBox tbprice2;
        private System.Windows.Forms.Button srchbutton;
        private System.Windows.Forms.DataGridView dgvstores;
    }
}


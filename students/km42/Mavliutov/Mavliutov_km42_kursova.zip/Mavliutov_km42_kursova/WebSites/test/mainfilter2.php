<?php
if(isset($_COOKIE['login'])){
    header("Location: personalpage.php"); exit;
}
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Logo Nav - Start Bootstrap Template</title>

	<!--<link rel="stylesheet" href="css/style.css">-->
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/logo-nav.css" rel="stylesheet">
	
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/js/valid/Bvalidator/dist/js/bootstrapValidator.min.js"></script>
	<script src="vendor/js/valid/index.js"></script>
	
	

  </head>

  <body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="http://placehold.it/300x60?text=Logo" width="150" height="30" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#ex2">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Sign up</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Sign in</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Page Content -->
    <div class="container">
      <h1 class="mt-5">Logo Nav by Start Bootstrap</h1>
      <p>The logo in the navbar is now a default Bootstrap feature in Bootstrap 4! Make sure to set the width and height of the logo within the HTML. For best results, it's recommended that you use an SVG image as your logo.</p>
	Итоги первой части сезона для динамовской команды U-21 мы подвели вместе с ее наставником Юрием Морозом:
<section id="ex1">
- Первая часть сезона завершена, довольны ли вы выступлением своих подопечных?</section>

<img src="css/image/match.svg">
- В целом, да. То, что было запланировано, мы сделали – и футболисты и тренеры. Но, конечно, хотелось сделать еще больше. Есть, над чем работать. Надеюсь, после отпуска ребята вернутся с таким же вдохновением и продолжат трудиться с таким же желанием, чтобы во время зимнего перерыва хорошо подготовиться к весенней части сезона, получать игровой опыт и расти в профессиональном плане.

- Что вы сказали подопечным перед отпуском? Они заслужили хороший отдых?

	<div class="form">
			<form  action="mainfilter.php" method="POST" id="tryitForm">
				<fieldset>
				<div class="form-group">
					<hr>
					<label for="filter"><b>Search Tournament</b></label>
					<input type="text" name="filter_tournament_name" pattern="^[A-z0-9]{1,10}$" title="This value is not valid" class="form-control" placeholder="Tournament name" required/>
				</div>			
				<div class="form-group">
					<button type="submit" class="btn btn-warning" >SEARCH<span class="glyphicon glyphicon-send"></span></button>
				</div>
				</fieldset>
			</form>			
	</div>
	
	<?php
		// Подключается к XE сервису (т.е. к базе данных) на "localhost"
		$connect = oci_connect('YAROSLAV', 'mavliutov1997', 'localhost/XE');
		if (!$connect) {
			$e = oci_error();
			trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
		}

		$countmytourn = oci_parse($connect, 'SELECT getcountmainfilter(:filters) FROM dual');
		$filt =  mb_strtolower($_POST['filter_tournament_name'])."%";
		oci_bind_by_name($countmytourn, ":filters", $filt);
		oci_execute($countmytourn);
		$row = oci_fetch_array($countmytourn, OCI_ASSOC);
		if (!$row) {$mycount = 0;}
		else {foreach ($row as $mycount){}}
		echo '<h3 class="mt-5">'.$mycount.' RESULTS</h3>';
			
		$stid = oci_parse($connect, 'SELECT tourn_id, org_login_fk,
									 tourn_name,tourn_data_started, tourn_data_end
									 FROM Tournament_for_admin
									 where lower(tourn_name) LIKE :filters');
		oci_bind_by_name($stid, ":filters", $filt);
		oci_execute($stid);

		$i = 0;
		$tourns = array();
		while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
			$j = 0;
			foreach ($row as $item) {
				if($item !== null) $tourns[$i][$j] = (htmlentities($item, ENT_QUOTES));
				$j++;
			}
			$i++;
		}
		for ($i = 0; $i < count($tourns); $i++) {
			$name = $tourns[$i][1];
			$id = $tourns[$i][0];
			$nametourn = $tourns[$i][2];
			echo '<hr><font color="317E0E"><b>Name Tournament: </b></font>'.$tourns[$i][2].'<br>'.' <font color="317E0E"><b>Start Date: </b></font>'.$tourns[$i][3].'<br>'.' <font color="317E0E"><b>End Date: </b></font>'.$tourns[$i][4].'<br>'.'
				 <form method="POST" action="abouttournamentmain.php">
				 <input name="id_tourn" type="hidden" class="form-control" value="'.$id.'" required/>
				 <input name="org_login" type="hidden" class="form-control" value="'.$name.'" required/>	 
				 <input name="tourn_n" type="hidden" class="form-control" value="'.$nametourn.'" required/>	
				 <button class="btn btn-blue btn-fill-vert">more details</button>
				 </form> ';
		}
		oci_free_statement($countmytourn);
		oci_free_statement($stid);
		oci_close($connect);
		
	?>
	
	
<section id="ex2">
- Конечно. По потерянным очкам мы на первом месте. Было много хороших игр, и просто отличных поединков. В следующем году все еще будет продолжаться, вся борьба впереди. Состав остальных команд молодежного первенства очень приличный, отсюда и плотность в турнирных очках. Каждый соперник может отобрать очки у лидеров. Особенно сложно было играть с первой десяткой. Каждая команда билась, старалась, поэтому проходных матчей у нас почти не было.

- Команда в 18 матчах потерпела три поражения и трижды сыграла вничью. Какая из этих потерь очков самая неприятная и обидная?

- Каждая из них была неприятной. Где-то сами теряли концентрацию, где-то не хватало уверенности, особенно, в первых матчах. Выделить один поединок, который стоял бы особняком, не могу. Из любой неудачи нужно делать выводы, обсуждать, пытаться исправить ситуацию – это ребята и старались делать. Главное, они воспринимают то, что мы до них доносим и воплощают это не только на теории, но и на практике. Непростой переход ребят из команды U-19 в U-21? Думаю, он в том числе также сказался.

- У молодежной команды «Динамо» впечатляющая разница забитых и пропущенных мячей - 51:13 (+38), вы можете быть довольны таким показателем?

- В принципе, да. Но у нас еще немного хромает надежность игры в обороне и отборе мяча. Над этими компонентами нам нужно больше трудиться. Всегда хочется лучшего, ведь нет предела совершенству. Надеюсь, ребята также это понимают. Посмотрим, как нам удастся с этим справиться в новом году. В то же время, хорошо, что они совершенствуются в игровом плане, кондициях, у них есть стимул. Плюс, наши игроки пытаются вырабатывать в себе дух победителей, и при этом расти в профессиональном плане, быть конкурентоспособными исполнителями для первой команды. Эти качества дорогого стоят.
	
	
</section>
	
	
	
	</div>

  </body>

</html>
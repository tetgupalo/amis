from flask import Flask, render_template, request, redirect, url_for, session
from flask_api import status
from forms import LoginForm, RegisterForm, ApartmentForm, FacilityForm
from werkzeug.utils import secure_filename
from datetime import timedelta
import cx_Oracle
import sys
import os
import views
import re
from datetime import datetime as dtme, date, timedelta
import datetime

UPLOAD_FOLDER = '/home/vavadimir/FlaskApp/FlaskApp/static/'
STATIC_FOLDER = '/static/'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])

os.environ['NLS_LANG'] = 'American_America.AL32UTF8'
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'super secret key'
app.config['SESSION_TYPE'] = 'filesystem'

con = cx_Oracle.connect('KOZYK2/Qwer1234@192.168.56.101/xe')

def daterange(date1, date2):
    for n in range(int ((date2 - date1).days)+1):
        yield date1 + timedelta(n)

def reg_maker(reg_info, cur):
    reg_string = ', '.join(['\'%s\'' % el if type(el) == str else str(el) for el in reg_info])
    request = 'BEGIN ADD_USER(%s); END;' % reg_string
    print(request)
    cur.execute(request)

def apart_maker(apart_info, apart_photos, cur):
    info = ', '.join(['\'%s\'' % el if type(el) == str else str(el) for el in apart_info])
    cur.execute("DECLARE emp PHOTOARRAY; BEGIN emp := PHOTOARRAY(%s); ADD_APARTMENT(%s, emp); END;" % (apart_photos, info))
    
    

def facility_maker(facility_info, cur):
    pattern = re.compile('^TO_DATE')
    reg_string = ', '.join(['\'%s\'' % el if (type(el) == str and not pattern.match(el)) else str(el) for el in facility_info])
    request = 'BEGIN ADD_FACILITY(%s); END;' % reg_string
    cur.execute(request)

def filter_facilities(filter_query, cur):
    query = {}
    right = []
    not_right = []
    for el in filter_query:
        query[str(el)] = filter_query.getlist(str(el))[0]
    if query['booking_end'] or query['booking_date']:
        filter_where = []
        date_end = query['booking_end'] if query['booking_end'] else query['booking_date']
        date_start = query['booking_date'] if query['booking_date'] else query['booking_end']
        filter_where.append('DATE_START <= TO_DATE(\'%s\', \'YYYY-mm-dd\')' % str(date_end))
        filter_where.append('DATE_END >= TO_DATE(\'%s\', \'YYYY-mm-dd\')' % str(date_start))
        filter_where.append('FACILITY_CITY=\'%s\'' % query['city'] if query['city'] else '')
        filter_where.append('FACILITY_PRICE>=\'%s\'' % query['min_price'] if query['min_price'] else '')
        filter_where.append('FACILITY_PRICE<=\'%s\'' % query['max_price'] if query['max_price'] else '')
        request = 'SELECT * FROM AVAILABLEFACILITIES' + ' WHERE ' + ' AND '.join([clause for clause in filter_where if clause != ''])
        cur.execute(request)
        return cur.fetchall()
    else:
        filter_where = []
        filter_where.append('FACILITY_CITY=\'%s\'' % query['city'] if query['city'] else '')
        filter_where.append('FACILITY_PRICE>=\'%s\'' % query['min_price'] if query['min_price'] else '')
        filter_where.append('FACILITY_PRICE<=\'%s\'' % query['max_price'] if query['max_price'] else '')
        request = 'SELECT * FROM AVAILABLEFACILITIES' + ' WHERE ' + ' AND '.join([clause for clause in filter_where if clause != ''])
        cur.execute(request)
        return cur.fetchall()
        
    
def filter_apartment(filter_query, cur):
    query = {}
    right = []
    not_right = []
    for el in filter_query:
        query[str(el)] = filter_query.getlist(str(el))[0]
    if query['booking_end'] or query['booking_date']:
        date_end = query['booking_end'] if query['booking_end'] else query['booking_date']
        date_start = query['booking_date'] if query['booking_date'] else query['booking_end']
        filter_where = []
        filter_where.append('CITY=\'%s\'' % query['city'] if query['city'] else '')
        filter_where.append('APARTMENT_PRICE>=\'%s\'' % query['min_price'] if query['min_price'] else '')
        filter_where.append('APARTMENT_PRICE<=\'%s\'' % query['max_price'] if query['max_price'] else '')
        request = 'SELECT * FROM BOOKDATES' + ' WHERE ' + ' AND '.join([clause for clause in filter_where if clause != ''])
        cur.execute(request)
        flds = [cur.description[i][0] for i in range(len(cur.description))]
        for dt in cur.fetchall():
            temp = dict(zip(flds,dt))
            if not temp['BOOKING_DATE'] and not temp['BOOKING_END']:
                right.append(temp['ID'])
            elif ((dtme.strptime(date_start, '%Y-%m-%d')) <= temp['BOOKING_END']) and ((dtme.strptime(date_end, '%Y-%m-%d')) >= temp['BOOKING_DATE']):
                not_right.append(temp['ID'])
            else:
                right.append(temp['ID'])
        right = tuple(set(right) - set(not_right))
        if right:
            cur.execute('SELECT * FROM APARTMENTLIST WHERE ID IN %s' % str(right))
            return cur.fetchall()
        else:
            return None
    else:
        filter_where = []
        filter_where.append('CITY=\'%s\'' % query['city'] if query['city'] else '')
        filter_where.append('APARTMENT_PRICE>=\'%s\'' % query['min_price'] if query['min_price'] else '')
        filter_where.append('APARTMENT_PRICE<=\'%s\'' % query['max_price'] if query['max_price'] else '')
        request = 'SELECT * FROM APARTMENTLIST' + ' WHERE ' + ' AND '.join([clause for clause in filter_where if clause != ''])
        try:
            cur.execute(request)
            return cur.fetchall()
        except:
            return None
        
   

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=30)

@app.route("/", methods=['GET', 'POST'])
def hello():
    cur = con.cursor()
    cur.execute('SELECT * FROM CITYLIST')
    cities = []
    for row in cur.fetchall():
        cities.append(row[0])
    if not request.args:
        cur.execute('select * from APARTMENTLIST')
        fields = ['id', 'city','street', 'price', 'description', 'dwellers', 'photo']
        fields_fac = ['id', 'name', 'city', 'street', 'date_start', 'date_end', 'price', 'description']
        apartment = []
        facility = []
        for row in cur.fetchall():
            apartment.append({x:y for x, y in zip(fields, row)})
        cur.execute('select * from AVAILABLEFACILITIES')
        for row in cur.fetchall():
            facility.append({x:y for x, y in zip(fields_fac, row)})
    else:
        fields = ['id', 'city','street', 'price', 'description', 'dwellers', 'photo']
        fields_fac = ['id', 'name', 'city', 'street', 'date_start', 'date_end', 'price', 'description']
        apartment = []
        facility = []
        try:
            for row in filter_apartment(request.args, cur):
                apartment.append({x:y for x, y in zip(fields, row)})
        except:
            apatment = None
        try:    
            for row in filter_facilities(request.args, cur):
                facility.append({x:y for x, y in zip(fields_fac, row)})
        except:
            facility = None
            
    return render_template("index.html", title='Home', apartment=apartment, facility=facility, cities=cities)
    
    

@app.route("/hello")
def hello_view():
    cur = con.cursor()
    cur.execute('select * from ROLE')
    print(cur)
    for row in cur.fetchall():
        print(row)
    cur.close()
    return "It`s works"

@app.route("/image/<filename>", methods=['GET'])
def image_view(filename):
    return render_template("image.html", title='Image', filename=filename)

@app.route("/login", methods=['GET', 'POST'])
def authentication():
    error_msg = ''
    form = LoginForm()
    try: 
        sess = session['logged_in']
    except:
        sess = False
    if request.method == 'GET' and sess:
        return redirect(url_for('hello'))
    elif request.method == 'GET' and not sess:
        return render_template("login.html", title='Login', form=form)
      
    if request.method == 'POST' and form.validate() and not sess:
        email_req = request.form['email']
        pass_req = request.form['password']
        cur = con.cursor()
        cur.execute('SELECT role_name_fk, email, password FROM "User"')
        for user in cur.fetchall():
            if (email_req, pass_req) == (user[1], user[2]):
                session['logged_in'] = True
                session['email'] = email_req
                session['role'] = user[0]
                break
        cur.close()
        try:
            session['logged_in']
            return redirect(url_for('hello'))
        except:
            return render_template("login.html", title='Login', form=form)
           

@app.route("/logout", methods=['GET'])
def logout():
    try:
        if session['logged_in']:
            session.clear()
            return redirect(url_for('hello'))
    except:
            return redirect(url_for('hello'))
    
@app.route("/register", methods=['POST', 'GET'])
def register():
    error_msg = ''
    form = RegisterForm()
    try: 
        sess = session['logged_in']
    except:
        sess = False
    if request.method == 'GET' and sess:
        return redirect(url_for('hello'))
    elif request.method == 'GET' and not sess:
        return render_template("register.html", title='Register', form=form)
      
    if request.method == 'POST' and form.validate() and not sess:
        cur = con.cursor()
        fields = ['role', 'email', 'name', 'password', 'phone_number']
        user_info = [request.form[fld] for fld in fields]
        print(user_info)
        for file in request.files.getlist("scan_path_doc"):
            filename = 'docs/' + secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        photos = ['docs/' + secure_filename(file.filename) for pht in request.files.getlist("scan_path_doc")]
        user_info.append(photos[0])
        reg_maker(user_info, cur)
        return redirect(url_for('hello'))
    elif request.method == 'POST' and sess:
        return None
    else:
        return render_template("register.html", title='Register', form=form)

@app.route("/add_apartment", methods=['GET', 'POST'])
def add_apartment():
    error_msg = ''
    form = ApartmentForm()
    try:
        role = session['role']
    except:
        role = None
    if request.method == 'GET' and (role == 'Landlord' or role == 'Admin'):
        return render_template("add_apartment.html", title='Add apartment', form=form)
    else:
        return None
    if request.method == 'POST' and (role == 'Landlord' or role == 'Admin'):
        fields = ['email', 'city', 'street', 'price', 'description', 'dwellers', 'number']
        apartment_info = [request.form[fld] for fld in fields]
        cur = con.cursor()
        for file in request.files.getlist("photos"):
            filename = 'apartments/' + secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        photos = ['apartments/' + secure_filename(file.filename) for pht in request.files.getlist("photos")]
        photoquery = ', '.join(['\'%s\'' % pht for pht in photos])
        apart_maker(apartment_info, photoquery, cur)
        return redirect(url_for('hello'))
    else:
        return None


@app.route("/add_facility", methods=['GET', 'POST'])
def add_facility():
    error_msg = ''
    form = FacilityForm()
    try:
        role = session['role']
    except:
        role = None
    if request.method == 'GET' and (role == 'Organizer' or role == 'Admin'):
        return render_template("add_facility.html", title='Add facility', form=form)
    else:
        return None
    if request.method == 'POST' and (role == 'Organizer' or role == 'Admin'):
        cur = con.cursor()
        fields = ['organizer', 'name', 'city', 'street', 'start', 'end', 'tickets', 'price', 'description']
        if request.form['start'] > request.form['end']:
            return render_template("add_facility.html", title='Add facility', form=form)
        inf = [request.form[fld] if (fld != 'start' and fld != 'end') else 'TO_DATE(\'%s\', \'yyyy-mm-dd\')' % request.form[fld] for fld in fields]
        facility_maker(inf, cur)
    else:
        return None


@app.route("/apartment/<apart_id>", methods=['GET'])
def apartment_detail(apart_id):
    cur = con.cursor()
    booked = []
    form = ApartmentForm()
    try:
        cur.execute('SELECT * FROM APARTMENTDETAIL WHERE ID=%s' % apart_id)
    except:
        return None
    res = cur.fetchone()
    try:
        cur.execute('SELECT APARTMENT_PHOTO_PATH FROM APARTMENTPHOTO WHERE ID=%s' % apart_id)
        photos = [el[0] for el in cur.fetchall()]
    except: 
        photos = None
    cur.execute('SELECT * FROM BOOKDATES WHERE ID=%s' % apart_id)
    try:
        for s in cur.fetchall():
            booked += [el.date() for el in daterange(s[3], s[4])]
    except:
        booked = []
    available_dates = [(dt, True) if dt not in booked else (dt, False) for dt in daterange(date.today(), date.today() + datetime.timedelta(days=60))]
    if res:
        fields = ['id', 'landlord','city', 'street', 'price', 'description', 'dwellers', 'add_number']
        apart = {x:y for x, y in zip(fields, res)}
        return render_template("apartment_detail.html", title="Apartment detail", apart=apart, photos=photos, dates=available_dates, form=form)
    else:
        return 'none'


@app.route("/apartments", methods=['GET', 'POST'])
def apartments():
    if request.method == 'GET':
        cur = con.cursor()
        cur.execute('SELECT * FROM CITYLIST')
        cities = []
        for row in cur.fetchall():
            cities.append(row[0])
        cur.execute('select * from APARTMENTLIST')
        fields = ['id', 'city','street', 'price', 'description', 'dwellers', 'photo']
        apartment = []
        facility = []
        for row in cur.fetchall():
            apartment.append({x:y for x, y in zip(fields, row)})
        return render_template("apartments.html", title='Home', apartment=apartment, cities=cities)
    elif request.method == 'POST':
        cur = con.cursor()
        city = request.form['city'] if request.form['city'] != '' else 'NULL'
        min_price = request.form['min_price'] if request.form['min_price'] != '' else 'NULL'
        max_price = request.form['max_price'] if request.form['max_price'] != '' else 'NULL'
        print('SELECT * FROM TABLE(FILTER_APARTMENT(\'%s\', %s, %s));' % (city, max_price, min_price))
        cur.execute('SELECT * FROM TABLE(FILTER_APARTMENT(\'%s\', %s, %s))' % (city, max_price, min_price))
        fields = ['id', 'city','street', 'price', 'description', 'dwellers', 'photo']
        apartment = []
        facility = []
        for row in cur.fetchall():
            apartment.append({x:y for x, y in zip(fields, row)})
            
        return render_template("filtered_apartments.html", apartment=apartment)
        


@app.route("/facility/<fac_id>", methods=['GET'])
def facility_detail(fac_id):
    cur = con.cursor()
    form = FacilityForm()
    fields = ['id', 'name', 'city', 'street', 'start', 'end', 'price', 'description', 'tickets']
    cur.execute('SELECT * FROM FACILITYDETAIL WHERE FACILITY_ID=%s' % fac_id)
    try:
        res = cur.fetchone()
    except:
        return None
    fac = {x:y for x, y in zip(fields, res)}
    return render_template("facility_detail.html", title="Facility detail", fac=fac, form=form)


@app.route("/book_facility", methods=['POST'])
def book_facility():
    if session['role'] == 'Vacationer' or session['role'] == 'Admin':
        cur = con.cursor()
        us = request.form['user']
        facility = request.form['facility']
        reg_string = '%s, \'%s\'' %(facility, us)
        rq = 'BEGIN BOOK_FACILITY(%s); END;' % reg_string
        cur.execute(rq)
        return 'here'


@app.route("/book_apartment", methods=['POST'])
def book_apartment():
    if session['role'] == 'Vacationer' or session['role'] == 'Admin':
        cur = con.cursor()
        us = request.form['user']
        apartment = request.form['apartment']
        date_start = request.form['date_start']
        date_end = request.form['date_end']
        reg_string = '%s ,\'%s\', TO_DATE(\'%s\', \'YYYY-mm-dd\'), TO_DATE(\'%s\', \'YYYY-mm-dd\')' % (apartment, us, date_start, date_end)
        print(reg_string)
        rq = 'BEGIN BOOK_APARTMENT(%s); END;' % reg_string
        try:
            cur.execute(rq)
        except:
            return None
        return 'here'


@app.route("/bookings", methods=['GET'])
def bookings():
    cur = con.cursor()
    bookings = []
    facilities = []
    fields = ['id', 'city', 'street', 'price', 'start_date', 'end_date', 'op_date']
    fields_fac = ['id', 'name', 'city', 'street', 'date_start', 'date_end', 'price', 'op_date', 'is_deleted']
    if session['logged_in'] and (session['role'] == 'Vacationer'):
        reg_string = 'SELECT ID, CITY, STREET, APARTMENT_PRICE, BOOKING_DATE, BOOKING_END, OPERATION_DATE FROM BOOKINGLIST WHERE BOOKER_EMAIL_FK = \'%s\'' % session['email']
        fac_string = 'SELECT FACILITY_ID, FACILITY_NAME, FACILITY_CITY, FACILITY_STREET, FACILITY_PRICE, DATE_START, DATE_END, DATE_OF_OPERATION FROM BOOKINGFACILITIES WHERE BOOKER_EMAIL_FK = \'%s\'' % session['email']
        try:
            cur.execute(reg_string)
            try:
                for row in cur.fetchall():
                    bookings.append({x:y for x, y in zip(fields, row)})
            except:
                pass
        except:
            bookings = None
        try:
            cur.execute(fac_string)
            try:
                for row in cur.fetchall():
                    facilities.append({x:y for x, y in zip(fields, row)})
            except:
                pass
        except:
            facilities = None
        return render_template('bookings.html', title='My bookings', bookings=bookings, facilities=facilities)
    else:
        return 'none'


@app.route("/orders", methods=['GET'])
def orders():
    cur = con.cursor()
    facilities = []
    bookings = []
    fields_fac = ['name', 'city', 'street', 'date_start', 'date_end', 'price', 'op_date', 'is_deleted']
    if session['logged_in'] and (session['role'] == 'Organizer'):
        fac_string = 'SELECT FACILITY_NAME, FACILITY_CITY, FACILITY_STREET, FACILITY_PRICE, DATE_START, DATE_END, DATE_OF_OPERATION FROM BOOKINGFACILITIES WHERE ORGANIZER_EMAIL_FK = \'%s\'' % session['email']
        try:
            cur.execute(fac_strings)
            try:
                for row in cur.fetchall():
                    facilities.append({x:y for x, y in zip(fields_fac, row)})
            except:
                pass
        except:
            facilities = None
        return render_template('orders.html', title='Orders', bookings=None, facilities=facilities)
    elif session['logged_in'] and (session['role'] == 'Landlord'):
        fields = ['city', 'street', 'price', 'start_date', 'end_date', 'op_date']
        reg_string = 'SELECT CITY, STREET, APARTMENT_PRICE, BOOKING_DATE, BOOKING_END, OPERATION_DATE FROM BOOKINGLIST WHERE LANDLORD_EMAIL_FK = \'%s\'' % session['email']
        try:
            cur.execute(reg_string)
            try:
                for row in cur.fetchall():
                    bookings.append({x:y for x, y in zip(fields, row)})
            except:
                pass
        except:
            bookings = None
        return render_template('orders.html', title='Orders', bookings=bookings, facilities=None)
    else:
        return 'none'
    
    
@app.route("/apartment/<id>/edit", methods=['POST'])
def edit_apartment(id):
    print('tyt')
    cur = con.cursor()
    cur.execute("BEGIN UPDATE_APARTMENT(%s, \'%s\', %s, %s, \'%s\', \'%s\'); END;" % (id, request.form['street'], request.form['price'], request.form['dwellers'],
                                                                                      request.form['description'], request.form['number']
                                                                                  ))
    print('good')
        
      
@app.route("/apartment/<id>/delete", methods=['GET'])
def delete_apartment(id):
    cur = con.cursor()
    cur.execute("BEGIN DEL_APARTMENT(%s); END;" % id)

@app.route("/facility/<id>/edit", methods=['POST'])
def edit_facility(id):
    cur = con.cursor()
    print('tyt')
    cur.execute("BEGIN UPDATE_FACILITY(%s, \'%s\', %s, \'%s\'); END;" % (id, request.form['street'], request.form['price'], request.form['description']))
    print('good')

@app.route("/facility/<id>/delete", methods=['GET'])
def delete_facility(id):
    cur = con.cursor()
    cur.execute("BEGIN DEL_APARTMENT(%s); END;" % id)
    
@app.route("/paneladmin", methods=['GET', 'POST'])
def admin_panel():
    if session['role'] == 'Admin':
        cur = con.cursor()
        users = []
        fields = ['role', 'email', 'name', 'phone', 'scan_doc_path']
        cur.execute("SELECT * FROM USERAPPLIES")
        try:
            for row in cur.fetchall():
                users.append({x:y for x, y in zip(fields, row)})
        except:
            users = None
        return render_template("admin.html", users=users)
    

@app.route("/confirm", methods=['POST'])
def confirm():
    cur = con.cursor()
    try:
        cur.execute('BEGIN CONFIRM_USER(\'%s\'); END;' % request.form['email'])
    except:
        return 'None'
    return 'confirmed'
    

@app.route("/decline", methods=['POST'])
def decline():
    cur = con.cursor()
    try:
        cur.execute('BEGIN DELETE_USER(\'%s\'); END;' % request.form['email'])
    except:
        return 'None'
    return 'deleted'


@app.route("/apartment/booking/delete", methods=['POST'])
def booking_apartment_delete():
    print(request.form)

@app.route("/facility/booking/delete", methods=['POST'])
def booking_facility_delete():
    print(request.form)

if __name__ == "__main__":
    session.init_app(app)
    app.run(debug=True)


from django.apps import AppConfig


class AdminsMenuConfig(AppConfig):
    name = 'admins_menu'

<?php

require('connect.php');



if (strcasecmp($_POST['action'], 'update') == 0 ) {
	/*$_POST['idtourn']
	$_POST['login_org']
	$_POST['tournament_name']
	$_POST['tournament_data_started']
	$_POST['tournament_data_end']*/
	$err = 0;
	$sdate =  date_format(date_create($_POST['tournament_data_started']),"d-M-Y ");
	$tournament = oci_parse($connect, 'select *
						from   Tournament_for_create
						where  tourn_name = :new_tourn_name
						and	   tourn_data_started =:new_tourn_data_started and tourn_del = :del');
	oci_bind_by_name($tournament, ":new_tourn_name", $_POST['tournament_name']);
	oci_bind_by_name($tournament, ":new_tourn_data_started", $sdate);
	$del = 0;
	oci_bind_by_name($tournament, ":del", $del);


	oci_execute($tournament) or die("No execute!");
	$rtournament = oci_fetch_array($tournament, OCI_ASSOC);
	
	$value_data_started = date_format(date_create($_POST['tournament_data_started']),"d-M-Y");
	$value_data_end = date_format(date_create($_POST['tournament_data_end']),"d-M-Y");
	$today = date("d-M-Y"); 

	if (($value_data_started > date_format(date_create($_POST['oldstart']),"d-M-Y")) or ($value_data_end < date_format(date_create($_POST['oldend']),"d-M-Y"))){
		$err = 1;
		echo ' поганий часовий інтервал';
	}
	if (!$rtournament and $err == 0) {
		
		$update = 'UPDATE TOURNAMENT_FOR_create SET TOURN_NAME = :newname, tourn_data_started = :newstart, tourn_data_end = :newend, tourn_id = :idtourn, org_login_fk = :login
					where tourn_id = :idtourn and org_login_fk = :login';
		$compiled = oci_parse($connect, $update);
		oci_bind_by_name($compiled, ':newname', $_POST['tournament_name']);
		oci_bind_by_name($compiled, ':newstart', $value_data_started);
		oci_bind_by_name($compiled, ':newend', $value_data_end);
		oci_bind_by_name($compiled, ':idtourn', $_POST['idtourn']);
		oci_bind_by_name($compiled, ':login', $_POST['login_org']);
		oci_execute($compiled, OCI_DEFAULT);
		oci_commit($connect);
		
		oci_free_statement($stid);
		oci_free_statement($tournament);
		oci_close($connect);
		
		header("Location: personalpage.php"); exit;
	} else {
		
		oci_free_statement($stid);
		oci_close($connect);
		echo 'Введіть норм дані';
		echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	}
	
	
} else if (strcasecmp($_POST['action'], 'delete') == 0 ) {
	 $select = oci_parse($connect, 'select *
                      from   Organizer_for_login
                      where  org_login = :new_login
                      and    org_pass = :new_pass');
	  oci_bind_by_name($select, ":new_login", $_COOKIE['login']);
	  oci_bind_by_name($select, ":new_pass", $_POST['organizer_password']);
	  oci_execute($select);
	  $r = oci_fetch_array($select, OCI_ASSOC);
	  if ($r) {
		
			
			$delete3 = 'BEGIN changespro.deletetourn(:login, :idtourn); END;';
			$compiled3 = oci_parse($connect, $delete3);
			oci_bind_by_name($compiled3, ':idtourn', $_POST['idtourn']);

			oci_bind_by_name($compiled3, ':login', $_POST['login_org']);
			oci_execute($compiled3);
			oci_commit($connect);
			
			
			
			
			oci_close($connect);
			header("Location: personalpage.php"); exit;
	  }
	  else {
		  
		  oci_free_statement($stid);
			oci_free_statement($select);
			oci_close($connect);
		  //header("Location: personalpage.php"); exit;
		  echo ' пароль не добрий';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	  }
	 }
	
	
	
	
	
?>
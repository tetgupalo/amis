from flask import Flask, render_template, request, redirect, url_for, session
import cx_Oracle

con = cx_Oracle.connect('KOZYK2/Qwer1234@192.168.56.101/xe')
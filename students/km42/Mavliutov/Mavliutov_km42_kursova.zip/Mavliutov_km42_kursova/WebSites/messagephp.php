<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php



require('connect.php');


$email = oci_parse($connect, 'select *
                    from   Team_for_admin
                    where  tm_email = :new_email');
oci_bind_by_name($email, ":new_email", $_POST['organizer_email']);
oci_execute($email) or die("No execute!");
$remail = oci_fetch_array($email, OCI_ASSOC);
if ($remail) {
	$value_mess = $_POST['messg'];
	$value_email = $_POST['organizer_email'];
	$value_org = $_COOKIE['login'];
	$today = date("d-M-Y"); 
	$insert = 'INSERT INTO MSG_for_admin(Msg_data, Tm_email_fk, Org_login_fk, msg_context) '.
				'VALUES(:data, :email, :login, :cont)';
	$compiled = oci_parse($connect, $insert);
	oci_bind_by_name($compiled, ':login', $value_org);
	oci_bind_by_name($compiled, ':email', $value_email);
	oci_bind_by_name($compiled, ':data', $today);
	oci_bind_by_name($compiled, ':cont', $value_mess);
	oci_execute($compiled);
	oci_commit($connect);
	
	oci_free_statement($email);
	oci_close($connect);
	header("Location: personalpage.php"); exit;
} else {
	oci_free_statement($email);
	oci_close($connect);
	echo 'нема такої команди';
			echo '<form action="messagephp.php">
			<button type="submit">Добре(</button>
		</form>';
    //header("Location: message.php"); exit;
}
	

?>
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, IntegerField, FileField, FloatField, DateField
from wtforms.validators import DataRequired, Email
from wtforms import validators
from wtforms.fields.html5 import EmailField

class LoginForm(FlaskForm):
    email = EmailField('Email address', [DataRequired(), Email()])
    password = PasswordField('Password', [DataRequired(), validators.Length(min=1, max=20)])


class RegisterForm(FlaskForm):
    role = SelectField('Роль', choices=[('Vacationer', 'Відпочиваючий'), ('Landlord', 'Орендодавець'), ('Organizer', 'Організатор')])
    email = EmailField('Електронна пошта', [DataRequired(), Email()])
    name = StringField('Ім’я', [validators.Length(min=1, max=20)])
    password = PasswordField('Пароль', [DataRequired(), validators.Length(min=6, max=25)])
    phone_number = StringField('Номер телефону', [validators.Length(min=10, max=10), validators.required()])
    scan_path_doc = FileField('Скан документу')
    
    
class ApartmentForm(FlaskForm):
    email = EmailField('Електронна пошта', [DataRequired(), Email()])
    city = StringField('Місто', [DataRequired(), validators.Length(min=1, max=20)])
    street = StringField('Вулиця', [DataRequired(), validators.Length(min=1, max=30)])
    price = FloatField('Ціна', [validators.required()])
    description = StringField('Опис', [DataRequired(), validators.Length(min=5, max=600)])
    dwellers = IntegerField('Кількість місць', [validators.required()])
    number = StringField('Додатковий номер', [validators.Length(min=10, max=10)])
    photos = FileField('pic', render_kw={'multiple': True})


class FacilityForm(FlaskForm):
    organizer = EmailField('Електронна пошта', [DataRequired(), Email()])
    name = StringField('Назва', [DataRequired(), validators.Length(min=1, max=30)])
    city = StringField('Місто', [DataRequired(), validators.Length(min=1, max=20)])
    street = StringField('Вулиця', [DataRequired(), validators.Length(min=1, max=40)])
    start = DateField('Дата початку', format='%m/%d/%Y')
    end =  DateField('Дата закінчення', format='%m/%d/%Y')
    tickets = IntegerField('Кількість квитків', [validators.required()])
    price = FloatField('Ціна', [validators.required()])
    description = StringField('Опис', [DataRequired(), validators.Length(min=5, max=600)])
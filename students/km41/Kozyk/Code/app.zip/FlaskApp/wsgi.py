from FlaskApp import flaskapp.app

if __name__ == "__main__":
    application.run()

from django.db import models

class Phone(models.Model):
    name = models.CharField(
        'Phone',
        max_length=30,
        default='No name',
    )
    description = models.CharField(
        'Description',
        max_length=255,
	    blank=True,
	    null=True,
    )
    price = models.PositiveIntegerField(
        'Price',
        null=True,
        blank=True,
        default=0,
    )
    model = models.CharField(
    	'Model',
    	max_length=30,
	    blank=True,
	    null=True,
    )
    quantity = models.PositiveIntegerField(
    	'quantity',
    	default=1,
    )
    phone_photo = models.ImageField(
    	'Phone photo',
    	upload_to='phone_image/',
    	blank=True,
    	default='phone_image/no_phone.jpg',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Phone"
        verbose_name_plural = "Phones"

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class AlterCompInstores : Form
    {
        public AlterCompInstores()
        {
            InitializeComponent();

        }
        bool buttonclicked = false;
        string[] combocompstuff = new string[1000];
        string[] combocompstuff2 = new string[1000];

        private void AlterCompInstores_Load(object sender, EventArgs e)
        {
            try
            {
                string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                    Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                SqlConnection sqlcon = new SqlConnection(connection);
                sqlcon.Open();
                DataTable dtbl = new DataTable("cis");
                using (var command = new SqlCommand("SELECT id, FullComputerName FROM dbo.Admin_FullComputerName", sqlcon))
                    dtbl.Load(command.ExecuteReader());
                //int k = dtbl.Rows.Count;
                //for (int i = 0; i<k; i++)
                //{
                //    combocompstuff = dtbl.Rows[i].ItemArray.Select(x => x.ToString()).ToArray();
                //    combocompstuff2[i] = combocompstuff[0] + combocompstuff[1];
                //}
                //combocompstuff = dtbl.Rows[0].ItemArray.Select(x => x.ToString()).ToArray();
                //label2.Text = combocompstuff[0];
                //label3.Text = combocompstuff[1];
                //combocomp.Items.AddRange(new object[] { combocompstuff2 });
                //DataSet myDataSet = new DataSet();
                //myDataSet.Tables.Add(dtbl);
                combocomp.ValueMember = "id";
                combocomp.DisplayMember = "FullComputerName";
                combocomp.DataSource = dtbl.DefaultView;
                combocomp.BindingContext = this.BindingContext;
                DataTable dtbl2 = new DataTable("cis2");
                using (var command2 = new SqlCommand("SELECT id, FullStoreName FROM dbo.Admin_FullStoreName", sqlcon))
                    dtbl2.Load(command2.ExecuteReader());
                combostore.ValueMember = "id";
                combostore.DisplayMember = "FullStoreName";
                combostore.DataSource = dtbl2.DefaultView;
                combostore.BindingContext = this.BindingContext;
                tbprice.Text = AdminCompInStores.price.ToString();
                rtbcomment.Text = AdminCompInStores.comment.ToString();
                combocomp.SelectedValue = AdminCompInStores.compid;
                combostore.SelectedValue = AdminCompInStores.storeid;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Changebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            if (Program.number.IsMatch(tbprice.Text.Trim()))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to update?", "Computers in stores", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                               Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                        SqlConnection sqlcon = new SqlConnection(connection);
                        sqlcon.Open();

                        string cmd = "UPDATE dbo.Admin_ComputerInStores SET comment=nullif('" + rtbcomment.Text +
                            "', ''), price=" + tbprice.Text + " , computer_id =" + combocomp.SelectedValue + ", store_id = "
                            + combostore.SelectedValue + " WHERE id=" + AdminCompInStores.id;
                        SqlCommand command = new SqlCommand(cmd, sqlcon);
                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                }

                AdminCompInStores acs = new AdminCompInStores();
                this.Hide();
                acs.Show();
            }
            else
            {
                MessageBox.Show("Price should be an integer!");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void addbutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to add?", "Computers in stores", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                           Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                    SqlConnection sqlcon = new SqlConnection(connection);
                    sqlcon.Open();
                    string cmd = "INSERT INTO dbo.Admin_ComputerInStores (price, comment, computer_id, store_id)" +
                        " values (" + tbprice.Text + ", nullif(N'" + rtbcomment.Text + "', N''), " + combocomp.SelectedValue
                        + ", " + combostore.SelectedValue + ")";
                    SqlCommand command = new SqlCommand(cmd, sqlcon);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            AdminCompInStores acs = new AdminCompInStores();
            this.Hide();
            acs.Show();

        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                       Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                    SqlConnection sqlcon = new SqlConnection(connection);
                    sqlcon.Open();
                    string cmd = "DELETE FROM dbo.Admin_ComputerInStores WHERE id=" + AdminCompInStores.id;
                    SqlCommand command = new SqlCommand(cmd, sqlcon);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            AdminCompInStores acs = new AdminCompInStores();
            this.Hide();
            acs.Show();
        }

        private void closebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                AdminCompInStores acs = new AdminCompInStores();
                this.Hide();
                acs.Show();
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
            rtbcomment.Text = "";
        }

        private void AlterCompInstores_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (buttonclicked == false)
            {
                AdminCompInStores acs = new AdminCompInStores();
                acs.Show();
            }
        }
    }
}

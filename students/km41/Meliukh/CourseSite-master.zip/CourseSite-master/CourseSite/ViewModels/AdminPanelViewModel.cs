﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CourseSite.ViewModels
{
    public class AdminPanelViewModel
    {
        public string UserName { get; set; }

        public string UserEmail { get; set; }

    }
}
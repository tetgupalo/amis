from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from .models import Order
from phones.models import Phone

@method_decorator(login_required, name='dispatch')
class OrderView(View):
    template_name = 'orders/order-details.html'

    def get(self, request, pk):
        user = request.user
        order = Order.objects.get(pk=pk)
        phone = order.phone
        context = {'phone': phone,
                   'user': user,
                   'order': order}

        return render(request, self.template_name, context)

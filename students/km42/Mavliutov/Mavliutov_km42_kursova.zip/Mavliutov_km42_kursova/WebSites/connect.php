<?php
$connect = oci_connect('YAROSLAV', 'mavliutov1997', 'localhost/XE');
if (!$connect) {
	$e = oci_error();
	trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
?>
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import render
import datetime
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.utils import timezone
from django.db import connection
from django.db import transaction
from .models import Car, ParkingPlace

@method_decorator(login_required, name='dispatch')
class ParkingDetails(View):

    def get(self, request, pk):
        parking_place = ParkingPlace.objects.get(pk=pk)

        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
                if parking_place.busy_to:
                    now = timezone.now()
                    if now >= parking_place.busy_to:
                        parking_place.car_parked = None
                        parking_place.busy_from = None
                        parking_place.busy_to = None
                        parking_place.save()


        cars = Car.objects.all()
        return render(request, 'parking-details.html',
                      {'parking_place': parking_place, 'cars': cars})

    def post(self, request, pk):
        
        parking_place = ParkingPlace.objects.get(pk=pk)
        cars = Car.objects.all()
        post_data = request.POST.getlist('car')
        car_id, hours = post_data[0], int(post_data[1])
        now = datetime.datetime.now()

        car = Car.objects.get(id=car_id)
        car.owner.add(request.user)

        parking_place.car_parked = car
        parking_place.busy_from = now
        parking_place.busy_to = now + datetime.timedelta(hours=hours)

        car.save()
        parking_place.save()

        return render(request, 'parking-details.html',
                          {'parking_place': parking_place, 'cars': cars})

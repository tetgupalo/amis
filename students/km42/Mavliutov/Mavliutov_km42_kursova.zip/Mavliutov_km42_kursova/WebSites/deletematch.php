<?php

require('connect.php');

if (strcasecmp($_POST['action'], 'delete') == 0 ) {
	
	/*$_POST['email1']
	$_POST['email2']
	$_POST['datamatch']*/
	 $select = oci_parse($connect, 'select *
                      from   Organizer_for_login
                      where  org_login = :new_login
                      and    org_pass = :new_pass');
	  oci_bind_by_name($select, ":new_login", $_COOKIE['login']);
	  oci_bind_by_name($select, ":new_pass", $_POST['organizer_password']);
	  oci_execute($select);
	  $r = oci_fetch_array($select, OCI_ASSOC);
	  if ($r) {
		
		$value_data = date_format(date_create($_POST['datamatch']),"d-M-Y");
		$delete = 'BEGIN changespro.deletematch(:em1, :em2, :time); END;';
		$compiled = oci_parse($connect, $delete);
		oci_bind_by_name($compiled, ':em1', $_POST['email1']);
		oci_bind_by_name($compiled, ':em2', $_POST['email2']);
		oci_bind_by_name($compiled, ':time', $value_data);
		oci_execute($compiled);
		oci_commit($connect);
		
		
		oci_free_statement($compiled);
		oci_close($connect);
		header("Location: personalpage.php"); exit;
	  }
	  else {
		  oci_free_statement($select);
		oci_close($connect);
		  //header("Location: personalpage.php"); exit;
		  echo ' пароль не добрий';
			echo '<form action="personalpage.php">
			<button type="submit">Добре(</button>
		</form>';
	  }
}

	
	
	
	
	
?>